<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recupere sua senha</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="css/signin.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css" rel="stylesheet">

</head>
<body style="background-color: #efedec">
    <form class="form-signin">
   
        <input type="password" id="inputNovaSenha" class="form-control" placeholder="Nova senha" required autofocus style="background: #b6b2ac; border-radius: 86px">
        <input type="password" id="inputConfNovaSenha" class="form-control" placeholder="Confirme a nova senha" required autofocus style="background: #b6b2ac; border-radius: 86px">
        <a class="btn btn-lg btn-primary btn-block" onclick="alert()" type="submit" style="background: #51524a; border-radius: 86px;" >CRIAR NOVA SENHA</a>
        <a href="index.php" style="position: absolute; top: 77%; left: 50%; transform: translate(-50%, -50%); "> Voltar</a>
       

        </form>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script>
            function alert() {
                const novaSenha = document.getElementById('inputNovaSenha').value;
                const confSenha = document.getElementById('inputConfNovaSenha').value;
              
                if (novaSenha.length < 8) {
                    Swal.fire({
                    title: 'Erro',
                    text: 'A nova senha deve ter pelo menos 8 caracteres.',
                    icon: 'error',
                    confirmButtonText: 'Ok'
                    });
                return;
                }

                if (novaSenha !== confSenha) {
                    Swal.fire({
                    title: 'Erro',
                    text: 'Senhas não coincidem.',
                    icon: 'error',
                    confirmButtonText: 'Ok'
                    });
                return;
                }

  // Se a validação passar, você pode prosseguir com a recuperação de senha
  // Aqui, você pode chamar uma função para enviar a nova senha ao servidor ou realizar outras ações necessárias.
  // Por exemplo:
  // enviarNovaSenhaAoServidor(novaSenha);

                Swal.fire({
                title: 'Sucesso',
                text: 'Senha recuperada com sucesso!',
                icon: 'success',
                confirmButtonText: 'Ok',
                }).then((result) => {
                        if (result.isConfirmed) {
                        // Redirecionar o usuário para "index.html"
                        window.location.href = 'index.php';
                        }
                    });
            }

    // Função para enviar a nova senha ao servidor
    //function enviarNovaSenhaAoServidor(novaSenha) {
    // Coloque aqui a lógica para enviar a nova senha ao servidor.
    // Pode ser uma solicitação AJAX, por exemplo.
    //}
        </script>
    </body>
</html>

