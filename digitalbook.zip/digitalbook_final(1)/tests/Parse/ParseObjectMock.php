<?php
/**
 * Created by PhpStorm.
 * User: Bfriedman
 * Date: 1/29/17
 * Time: 10:08 PM
 */

namespace Parse\Test;


use Parse\ParseObject;

class ParseObjectMock extends ParseObject
{

}