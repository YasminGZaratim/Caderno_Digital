<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sobre Nós</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-5iBSkpMXIq3iPaVxl8AOVhOpZjvTK69Mm0XJVKCjgFoiW2TJGXu8CJw6U+czZV2tkFw5ndGcQb0l+bs1N/8IdQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #282828;
      color: #fff;
      text-align: center;
      padding: 1em;
    }

    section {
      max-width: 800px;
      margin: 2em auto;
      padding: 2em;
      background-color: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }
    .team-member {
      text-align: center;
      margin-right:  37px;
      display: inline-block;
      margin-top:25px;
      margin-left: 100px;
    }

    .team-member img {
      width: 170px;
      height: 190px;
      border-radius: 50%;
      margin-bottom:  5px;
    }
    h2 {
      color: #282828;
    }

    p {
      color: #575757;
      line-height: 1.6;
    }

    footer {
      text-align: center;
      padding: 1em;
      background-color: #282828;
      color: #fff;
      position: fixed;
      bottom: 0;
      width: 100%;
    }
  </style>
</head>

<body>
  <header>
    <h1>Sobre Nós</h1>
  </header>
   
  <div class="team-member">
      <img src="imagens/jullya.jpg" style="width: 170px; height:190px" alt="Membro 1">
      <h2>Jullya Gomes Santos</h2>
    </div>

    <div class="team-member">
      <img src="imagens/yasmin.jpeg" style="width: 170px; height:190px"alt="Membro 2">
      <h2>Yasmin Gonçalves Zaratim</h2>
    </div>

    <div class="team-member">
      <img src="imagens/kevin.jpg" style="width: 170px; height:190px;" alt="Membro 3">
      <h2>Kevin Costa Ratero</h2>
    </div>
  
  <section>
    <h2>Nossa História</h2>
    <p>Em 2023, um grupo de adolescentes determinados embarcou em uma jornada desafiadora para concluir seu Trabalho de Conclusão de Curso (TCC). O objetivo era claro, mas o caminho estava repleto de desafios inesperados.</p>

<p>A cada etapa, enfrentamos obstáculos que testaram nossa resiliência e determinação. Desde a escolha do tema até a pesquisa exaustiva, cada fase trouxe novos desafios. No entanto, nossa paixão pelo aprendizado e o desejo de superar as adversidades nos impulsionaram.</p>

<p>Enfrentamos noites sem dormir, revisões intermináveis e momentos de dúvida. No entanto, como uma equipe unida, encontramos forças uns nos outros e descobrimos soluções criativas para os problemas. Cada dificuldade se tornou uma oportunidade de crescimento.</p>

<p>Ao final, não apenas concluímos com sucesso nosso TCC, mas também aprendemos lições valiosas sobre trabalho em equipe, perseverança e superação. Este capítulo de nossa história não é apenas sobre um projeto acadêmico, mas sobre a jornada de um grupo de adolescentes que se recusou a desistir diante das dificuldades.</p>
  </section>
  <footer>
    &copy; 2023 - Digital Book
  </footer>
</body>

</html>
