<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE-edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
  <link rel="stylesheet" href="css/nota.css">
  <link rel="icon" href="imagens/logo_original(8).png"style="width:1000px" type="image/x-icon">
  <title id="tituloPagina"> Sem título </title>
  <script src="https://kit.fontawesome.com/7b7cd02c9e.js" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body class="dark-mode">
  <!-- Seu conteúdo aqui -->
  <div class="notes" id="app">
    <div class="notes__sidebar">
      <div class="container">


      <img style="width: 120px; display: block; margin: 0 auto;" src="imagens/logo_original(8).png"/>

            <!--Barra de pesquisa -->
          <div class="pesquisa" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px;">
            
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 4px; margin-right: -30px; width: calc(100% - 8px);">
              
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: rgba(55, 53, 47, 0.65); width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                  
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: rgba(55, 53, 47, 0.45); flex-shrink: 0;">

                    </svg>
                  
                  </div>

                    <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis;">
                    
                          <i class="search icon " style="color: #ffffff; left:-30px"></i>Pesquisar
                        
                      
                    </div>
                
                </div>

              </div> 

            </div>


            <a href="tela_config_conta.php" class="configuracao" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px;">
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 0px; margin-right: 4px; width: calc(100% - 18px);">
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: #ffffff; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: #ffffff; flex-shrink: 0;"></svg>
                  </div>
                  <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis; color: #ffffff;">
                    <i class="configure icon" style="color: #ffffff;"></i>Configurações
                  </div>
                </div>
              </div>
            </a>


            <a href="tela_criar_novo_caderno.php" class="caderno" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px; color: #ffffff;">
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 0px; margin-right: 4px; width: calc(100% - 18px);">
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: #ffffff; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: #ffffff; flex-shrink: 0;"></svg>
                  </div>
                  <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis; color: #ffffff;">
                    <i class="book icon" style="color: #ffffff;"></i>Criar novo caderno
                  </div>
                </div>
              </div>
            </a>
          


            <div class="anotacao" id="minhaDiv" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px;">
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 4px; margin-right: 4px; width: calc(100% - 8px);" onclick="abrirPaginaAnotacoes()">
                  <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                      <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: rgba(55, 53, 47, 0.65); width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                          <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: rgba(55, 53, 47, 0.45); flex-shrink: 0;"></svg>
                      </div>
                      <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis;">
                          <i class="fa-solid fa-notes-medical" style="color: #ffffff;"></i> Adicione uma página
                      </div>
                  </div>
              </div>
          </div>
      
            <div class="lixeira" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px;">
            
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 4px; margin-right: 4px; width: calc(100% - 8px);">
              
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: rgba(55, 53, 47, 0.65); width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                  
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: rgba(55, 53, 47, 0.45); flex-shrink: 0;">

                    </svg>
                  
                  </div>

                    <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis;">
                    
                      <i class="trash icon"></i>Lixeira
                        
                      
                    </div>
                
                </div>

              </div> 

            </div>  


            </div>

         </div>
          <!-- Conteúdo Principal -->
    <div class="main-content">
      <div id="container">
          <h1 id="tituloPagina" contenteditable="true" oninput="atualizarTitulo()" onmouseover="mostrarAdicionarCapa()">Sem título</h1>
          <div id="opcaoAdicionar">
              <label id="fileLabel" for="fileInput">
                  <img style="width:20px; height: 25px; top:60px" src="imagens/icone_foto.jpg" alt="Câmera" id="cameraIcon">
                  Adicionar Capa
              </label>
              <input type="file" id="fileInput" style="display:none;" onchange="handleFileSelect(event)">
          </div>
      </div>
      <div class="container">
          <textarea contenteditable="true" oninput="autoResize(this); atualizarTexto();" placeholder="Digite seu texto aqui..." id="textarea"></textarea>
      </div>
      <div class="results"></div>
  </div>
  <div class="notes" id="app">
      <!-- Restante do seu código -->

      <div id="formatting-menu">
          <i class="fas fa-bold" onclick="applyBold()">B</i>
          <i class="fas fa-italic" onclick="applyItalic()">I</i>
          <i class="fas fa-underline" onclick="applyUnderline()">U</i>
          <!-- Adicione mais ícones conforme necessário -->
      </div>

      <button id="floating-icon" onclick="togglePageColor()">🌟</button>
  </div>

  <style>
    body {
      font-family: 'Arial', sans-serif;
      margin: 0;
      padding: 0;
    }
  
    .notes__sidebar {
      background-color: #195052;
      color: #ecf0f1;
      padding: 20px;
    }
  
    .logo {
      display: block;
      margin: 0 auto;
    }
  
    .search-bar {
      background-color: #195052;
      border-radius: 5px;
      padding: 8px;
      margin-top: 10px;
    }
  
    .search-icon {
      color: #ecf0f1;
    }
  
    .config-link,
    .note-link,
    .trash-link {
      color: #ecf0f1;
      text-decoration: none;
      display: block;
      margin-top: 15px;
    }
  
    .config-link:hover,
    .note-link:hover,
    .trash-link:hover {
      color: #3498db;
    }
  
    /* Estilos para a barra de pesquisa */
.pesquisa {
  display: flex;
  align-items: center;
  padding: 4px;
  margin: 0 4px;
  border-radius: 3px;
  background-color: #161616;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.pesquisa button {
  user-select: none;
  transition: background 20ms ease-in 0s;
  cursor: pointer;
  border-radius: 30px;
  margin-left: 4px;
  margin-right: -30px;
  width: calc(100% - 8px);
  background-color: #fff;
}

.pesquisa button:hover {
  background-color: #e0e0e0;
}

.pesquisa .icon-container {
  flex-shrink: 0;
  flex-grow: 0;
  border-radius: 40px;
  color: rgba(55, 53, 47, 0.65);
  width: 16px;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 4px;
  background-color: #ccc;
}

.pesquisa .icon-container svg {
  width: 14px;
  height: 100%;
  display: block;
  fill: rgba(55, 53, 47, 0.45);
  flex-shrink: 0;
}

.pesquisa .hover {
  flex: 1 1 auto;
  white-space: nowrap;
  min-width: 0px;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #ffffff;
}

/* Adicionando sombra à barra de pesquisa */
.pesquisa {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Posicionando à esquerda */
.pesquisa .icon-container,
.pesquisa .hover {
  margin-left: 4px;
}

/* Estilos para abas */
.notes .container .pesquisa,
.notes .container .configuracao,
.notes .container .caderno,
.notes .container .anotacao,
.notes .container .lixeira {
  display: flex;
  align-items: center;
  padding-bottom: 8px;
}

.notes .container a {
  flex-grow: 0;
  flex-shrink: 0;
  transition: background 20ms ease-in 0s;
  cursor: pointer;
  border-radius: 3px;
  margin-left: -30px;
  margin-right: 4px;
  width: calc(100% - 18px);
}

.notes .container a:hover {
  background-color: #e0e0e0;
}

.notes .container a .hover {
  flex: 1 1 auto;
  white-space: nowrap;
  min-width: 0px;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #ffffff;
}

.notes .container a .icon-container {
  flex-shrink: 0;
  flex-grow: 0;
  border-radius: 3px;
  color: #ffffff;
  width: 10px;
  height: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 8px;
  background-color: #161616;
}

.notes .container a .icon-container svg {
  width: 20px;
  height: 100%;
  display: block;
  fill: #ffffff;
  flex-shrink: 0;
}
#opcaoAdicionar {
      position: absolute;
      top: 170px;
      left: 554px;
      display: none;
    }

    #container:hover #opcaoAdicionar {
      display: block;
    }
    #tituloPagina {
      margin-right: 20px; /* Ajuste a margem para movê-lo para o lado direito */
      margin-bottom: 10px; /* Ajuste a margem para movê-lo para baixo */
      margin-top: 170px;
      margin-left: 170px;
    }

    #textarea {
      padding: 10px; /* Ajuste o preenchimento para dar espaço interno */
      margin-left: 170px;
      width: 70%;
            height: 100px; /* Defina a altura desejada inicial da textarea */
      margin-top: 10px ;
      color: inherit; /* Garante que a cor do texto seja herdada do contêiner */
      background-color: inherit; /* Garante que a cor de fundo seja herdada do contêiner */
      border: none;
    }
    #settings-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background-color: #3498db;
      color: #000000;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      text-align: center;
      line-height: 40px;
      cursor: pointer;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    /* Adicione estilos para o menu de configurações */
    #settings-menu {
      position: fixed;
      bottom: 70px;
      right: 20px;
      background-color: #fff;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      padding: 10px;
      max-width: 150px;
    }

    #settings-menu ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    #settings-menu li {
      cursor: pointer;
      padding: 5px;
    }

    #settings-menu li:hover {
      background-color: #f0f0f0;
    }
    /* Adicione seu CSS para a classe .highlighted-text conforme necessário */
    .highlighted-text {
      background-color: yellow;
      background-color: #3498db;
      background-color: aqua;
    }

    
   
    #settings-menu.hidden {
    display: none;
  }
  #formatting-menu {
      position: fixed;
      bottom: 20px;
      left: 59%;
      transform: translateX(-50%);
      margin-left:35px;
      
      padding: 10px;
      border-radius: 5px;
      box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
      width: 53%;
    }

    #formatting-menu i {
      font-size: 24px;
      margin: 0 10px;
      cursor: pointer;
    }
    #floating-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 50px;
      height: 50px;
      background-color: black;
      color: rgb(0, 0, 0);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background-color 0.3s, color 0.3s;
      color: rgb(0, 0, 0);
    }
    .dark-mode #floating-icon {
  color: white; /* Defina a cor do ícone para branco no modo claro */
}
    #textarea-container {
      position: fixed;
      bottom: 70px;
      right: 20px;
      background-color: rgb(255, 255, 255); /* Cor inicial da caixa de texto */
      color: white;
      padding: 10px;
      border-radius: 10px;
      display: none; /* Oculta inicialmente */
    }
  </style>
  
  <script src="js/nota.js"></script>
 
  <script>
   
    function autoResize(element) {
        element.style.height = "auto";
        element.style.height = (element.scrollHeight) + "px";
    }


    function mostrarAdicionarCapa() {
        document.getElementById('fileLabel').style.display = 'inline-block';
    }

    document.getElementById('fileLabel').addEventListener('click', function() {
        document.getElementById('fileInput').click();
    });
    function toggleSettingsMenu() {
    var settingsMenu = document.getElementById('settings-menu');
    settingsMenu.classList.toggle('hidden');
  }
  function changeFont() {
    var fontSelect = document.getElementById('fontSelect');
    var selectedFont = fontSelect.value;
    document.getElementById('tituloPagina').style.fontFamily = selectedFont;
    atualizarTitulo(); // Adicionei isso para atualizar o título quando a fonte for alterada
  }

    function changeParagraph() {
      var selectedParagraph = $('#paragraphSelect').val();
      $('#app').css('text-align', selectedParagraph);
    }

    function changeFontSize() {
      var selectedFontSize = $('#fontSizeSelect').val();
      $('#app').css('font-size', selectedFontSize);
    }

    function toggleHighlight() {
      $('#app').toggleClass('highlighted-text');
    }
    var isSettingsMenuVisible = false; // Adicionado para rastrear o estado do menu

function toggleSettingsMenu() {
  var settingsMenu = document.getElementById('settings-menu');
  isSettingsMenuVisible = !isSettingsMenuVisible; // Inverte o estado ao clicar

  if (isSettingsMenuVisible) {
    // Se o menu estiver visível, mostre-o
    settingsMenu.classList.remove('hidden');
  } else {
    // Se o menu estiver oculto, oculte-o
    settingsMenu.classList.add('hidden');
  }
}
 // Adiciona um ouvinte de evento para detectar quando o usuário está digitando
 document.addEventListener('keydown', function() {
      // Mostra o menu de formatação quando o usuário começa a digitar
      document.getElementById('formatting-menu').style.display = 'flex';
    });

   // Função para atualizar o título
   function atualizarTitulo() {
            const tituloPagina = document.getElementById('tituloPagina');
            const novoTitulo = tituloPagina.innerText;
            document.title = novoTitulo;
        }

        // Função para atualizar o texto
        function atualizarTexto() {
            const textarea = document.getElementById('textarea');
            const novoTexto = textarea.value;
            // Faça o que você quiser com o novoTexto, como salvá-lo em algum lugar.
        }

        // Função para adicionar capa (coloque a lógica aqui)

        // Funções para formatação (por exemplo, negrito, itálico, sublinhado)

        // Função para alternar cores (se você quiser adicionar isso)
        let isPageBlack = false;
        function togglePageColor() {
            const body = document.body;
            isPageBlack = !isPageBlack;
            if (isPageBlack) {
                body.style.backgroundColor = 'black';
                body.style.color = 'white';
            } else {
                body.style.backgroundColor = 'white';
                body.style.color = 'black';
            }
        }
  </script>
</body>
</html>
