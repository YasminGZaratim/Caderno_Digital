<?php
require 'autoload.php';
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseACL;
use Parse\ParsePush;
use Parse\ParseUser;
use Parse\ParseInstallation;
use Parse\ParseException;
use Parse\ParseAnalytics;
use Parse\ParseFile;
use Parse\ParseCloud;
use Parse\ParseClient;
$app_id='kdkpPwWeKAx2NPnxEVGWg10Rl9lKz15PbUvMwR4Y';
$rest_key='aW1fkOeY0KFgTWyrzru63krewpPhtxwSiUygTE7b';
$master_key='cNkmlGA5LLFAxeOCfW6ZYhkIPhCPYSeHbMihEGcB';
ParseClient::initialize( $app_id, $rest_key, $master_key );
// Users of Parse Server will need to point ParseClient at their remote URL and Mount Point:
ParseClient::setServerURL('https://parseapi.back4app.com','/');
//ParseClient::setHttpClient(new ParseStreamHttpClient());
ParseClient::setCAFile(__DIR__ . '/certs/cacert.pem');

//Cria a tabela
$object = ParseObject::create("Clientes");
$objectId = $object->getObjectId();
$php = $object->get("elephant");

//Coloca dados
$object->set("nome", "Alexei Bueno");

//Salva
$object->save();

// Or pass true to use the master key to override ACLs when saving:
$object->save(true);
 ?>
