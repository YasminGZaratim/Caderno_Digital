<?php
require 'autoload.php';
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseACL;
use Parse\ParsePush;
use Parse\ParseUser;
use Parse\ParseInstallation;
use Parse\ParseException;
use Parse\ParseAnalytics;
use Parse\ParseFile;
use Parse\ParseCloud;
use Parse\ParseClient;
$app_id='KxaEmPPcjtpdi2dpvY6FZ41PPZbvmucoNgcwUQNw';
$rest_key='swcBixrt6EvNMu2H2ElfcaXF6avPsmheO0VV6pNQ';
$master_key='ZDtk0mNobUSSEFytF5lCo10HCRuqRzvx2O86okZ6';
ParseClient::initialize( $app_id, $rest_key, $master_key );
// Users of Parse Server will need to point ParseClient at their remote URL and Mount Point:
ParseClient::setServerURL('https://parseapi.back4app.com','/');
//ParseClient::setHttpClient(new ParseStreamHttpClient());
ParseClient::setCAFile(__DIR__ . '/certs/cacert.pem');
$object = ParseObject::create("TestObject");
$objectId = $object->getObjectId();
$php = $object->get("elephant");

// Set values:
$object->set("elephant", "php");
$object->set("today", new DateTime());
$object->setArray("mylist", [1, 2, 3]);
$object->setAssociativeArray(
    "languageTypes", array("php" => "awesome", "ruby" => "wtf")
);

// Save normally:
$object->save();

// Or pass true to use the master key to override ACLs when saving:
$object->save(true);
 ?>
