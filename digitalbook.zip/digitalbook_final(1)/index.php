<?php
require 'autoload.php';
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseACL;
use Parse\ParsePush;
use Parse\ParseUser;
use Parse\ParseInstallation;
use Parse\ParseException;
use Parse\ParseAnalytics;
use Parse\ParseFile;
use Parse\ParseCloud;
use Parse\ParseClient;
$app_id='KxaEmPPcjtpdi2dpvY6FZ41PPZbvmucoNgcwUQNw';
$rest_key='swcBixrt6EvNMu2H2ElfcaXF6avPsmheO0VV6pNQ';
$master_key='ZDtk0mNobUSSEFytF5lCo10HCRuqRzvx2O86okZ6';
ParseClient::initialize( $app_id, $rest_key, $master_key );
// Users of Parse Server will need to point ParseClient at their remote URL and Mount Point:
ParseClient::setServerURL('https://parseapi.back4app.com','/');
ParseClient::setCAFile(__DIR__ . '/certs/cacert.pem');


//Inicia sessão
session_start();

if (isset($_POST["entrar"])) {
  $email = $_POST['email'];
  $senha = $_POST['senha'];

  $_SESSION['email'] = $email;

  $usuarioEncontrado = false;

  $query = new ParseQuery("Usuario");
  $query->equalTo("email", $email);
  $query->equalTo("senha", $senha);

  $query->each(function ($obj) use (&$usuarioEncontrado) {
      $usuarioEncontrado = true;
      header('Location: tela_anotacoes.php');
      exit(); // Adicione isso para interromper a execução adicional
  });

  if (!$usuarioEncontrado) {
      echo '<script>alert("Usuário não existe. Cadastre-se!");</script>';
  }
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="imagens/logo_original(8).png"style="width:1000px" type="image/x-icon">
    <title>Digital Book</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="css/signin.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css" rel="stylesheet">
</head>
<body style="background-color: #efedec;">

    <form class="form-signin" method="POST" id="login" action="index.php">
        <img style="width: 22%; position: absolute; top: 100px;" src="imagens/logo_original(circulo)(1).png" /> 
        <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email" autofocus style="background: #b6b2ac; border-radius: 86px; margin-top: 80%;">
        <p></p>
        <input type="password" name="senha" id="inputSenha" class="form-control" placeholder="Senha" style="background: #b6b2ac; border-radius: 86px">
        
       

        <p></p>
        
        <input type="submit" name="entrar" value="ENTRAR" onclick="alert()" style="margin-left:25%;background:#282828; border-radius: 86px; color:#fff; width: 154px; display: inline-block; text-align: center; text-decoration: none; padding: 6px;">
        
    <br><br><br>

        <a href="tela_rec_senha.php" style="position: absolute; top: 72%; left: 50%; transform: translate(-50%, -50%); margin-top: 20px;"> Esqueceu sua senha? Clique aqui!</a>
        <br><br><br><br><br>
        <a href="tela_cadastrar.php" style="position: absolute; top: 77%; left: 50%; transform: translate(-50%, -50%);"> É novo aqui? Crie uma conta!</a>
<br><br>
        <p class="mt-5 mb-3 text-muted" style="position:absolute; top: 79%; left: 50%; transform: translate(-50%, -50%);">&copy; since 2023</p>
      </form>

      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<script>
    function alert() {
      const email = document.getElementById('inputEmail').value;
      const senha = document.getElementById('inputSenha').value;
      const confirmarSenha = document.getElementById('inputConfSenha').value;
      
        if (!email || !validarEmail(email) || !senha || !validarSenha(senha)) {
          // Exibir mensagem de erro
          Swal.fire({
            title: 'Erro',
            text: 'Por favor, insira um email ou senha válidos.',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        } else {
          if (senha.length < 8) {
                    Swal.fire({
                    title: 'Erro',
                    text: 'A nova senha deve ter pelo menos 8 caracteres.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                    });
                return;
                }

                 else{
                  // Email e senha são válidos, mas usuário não existe
                  Swal.fire({
                  title: 'Usuário não existe, crie uma conta primeiro!',
                  icon: 'warning',
                  confirmButtonText: 'OK'
               }).then((result) => {
                    if (result.isConfirmed) {
                    // Redirecionar o usuário para tela_cadastar.php
                    window.location.href = 'tela_cadastrar.php';
            }
          });
                }
        }
        
      }
      
      function validarEmail(email) {
      const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return regexEmail.test(email);
    }
      
    function validarSenha(senha) {
    return senha.length >= 8;
    }
</script>

</body>
    
</html>


