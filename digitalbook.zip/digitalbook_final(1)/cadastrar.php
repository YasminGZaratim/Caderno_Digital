<?php
if (isset($_POST["Cadastrar"])){
	$ch = curl_init();

	//Dados do Backend
	$header = array(
		'X-Parse-Application-Id: KxaEmPPcjtpdi2dpvY6FZ41PPZbvmucoNgcwUQNw',
		'X-Parse-REST-API-Key: swcBixrt6EvNMu2H2ElfcaXF6avPsmheO0VV6pNQ',
		'Content-Type: application/json'
	);

	//Endereço da tabela
	curl_setopt($ch, CURLOPT_URL, "http://parseapi.back4app.com/parse/classes/Pedido");

	//Dados enviados pelo formulário
	$nome = $_POST['nome'];
	$descricao = $_POST['descricao'];

	//Dados para enviar para o servidor
	$dados = [
		'nome'=>$nome,
		'descricao'=>$descricao
	];			

	//echo json_encode($dados);

	//Executa
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 ); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header ); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($dados) ); 
	$result = curl_exec( $ch );
	curl_close($ch);
	
	echo "Incluído!";
}
?>
<form method="POST" action="cadastrar.php">
	Nome: <input type="text" name="nome"><br/>
	Descricão: <input type="text" name="descricao"><br/>
	<input type="submit" name="Cadastrar" value="Cadastrar">
	
</form>
<a href="listar.php">LISTAR</a>
