<?php
require 'autoload.php';
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseACL;
use Parse\ParsePush;
use Parse\ParseUser;
use Parse\ParseInstallation;
use Parse\ParseException;
use Parse\ParseAnalytics;
use Parse\ParseFile;
use Parse\ParseCloud;
use Parse\ParseClient;
$app_id='KxaEmPPcjtpdi2dpvY6FZ41PPZbvmucoNgcwUQNw';
$rest_key='swcBixrt6EvNMu2H2ElfcaXF6avPsmheO0VV6pNQ';
$master_key='ZDtk0mNobUSSEFytF5lCo10HCRuqRzvx2O86okZ6';
ParseClient::initialize( $app_id, $rest_key, $master_key );
ParseClient::setServerURL('https://parseapi.back4app.com','/');
ParseClient::setCAFile(__DIR__ . '/certs/cacert.pem');

//Inicia sessão
session_start();



if (isset($_REQUEST['act'])){
	if ($_REQUEST['act'] == "excluir"){
		$id = $_REQUEST['id'];
		$tabela = new Parse\ParseQuery("Nota");
		//Busca o registro específico
		$obj = $tabela->get($id);
		$obj->set("excluido", "1");
		//Salva
		$obj->save();

   
	}

	//Se clicou em cadastrar
	if ($_REQUEST['act'] == "cadastrar"){
		//Pego os dados do formulário
		$titulo = $_REQUEST['titulo'];
		$texto = $_REQUEST['texto'];
    

		//echo "titulo: ".$titulo;
		//echo "texto: ".$texto;    
		//exit();

		
		$tabela = ParseObject::create("Nota");
		
			
		$file = ParseFile::createFromData(file_get_contents($_FILES["file"]["tmp_name"]), $_FILES["file"]["name"]);
		$file->save();
		
		$tabela->set("titulo", $titulo);
		$tabela->set("texto", $texto);
		$tabela->set("foto", $file);
		$tabela->set("email", $_SESSION['email']);
		$tabela->save();
	}
}



?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE-edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
  <link rel="stylesheet" href="css/nota.css">
  <link rel="stylesheet" href="css/anotaçao.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-5iBSkpMXIq3iPaVxl8AOVhOpZjvTK69Mm0XJVKCjgFoiW2TJGXu8CJw6U+czZV2tkFw5ndGcQb0l+bs1N/8IdQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <link rel="icon" href="imagens/logo_original(8).png"style="width:1000px" type="image/x-icon">
  <title > Digital Book </title>
  
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
  
</head>
<body>
  <!-- Seu conteúdo aqui -->
  <div class="notes" id="app">
    <div class="notes__sidebar">
      <div class="container">
        

            
            <img style="width: 120px; display: block; margin: 0 auto;" src="imagens/logo_original(8).png"/>

            

        <!-- barra de pesquisa  -->
        <div class="wrap">
   <div class="search">
      <input type="text" class="searchTerm" placeholder="O que você está procurando?" name="pesquisa" id="areaPesquisa">
      <button type="submit" action="tela_anotacoes.php?act=botaoP" class="searchButton" name="botaoP" id="botaoPesquisa">
        <i class="fa fa-search"></i>
     </button>
   </div>
</div>


            <a href="tela_config_conta.php" class="configuracao" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px;">
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 0px; margin-right: 4px; width: calc(100% - 18px);">
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: #ffffff; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: #ffffff; flex-shrink: 0;"></svg>
                  </div>
                  <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis; color: #ffffff;">
                    <i class="configure icon" style="color: #ffffff;"></i>Configurações
                  </div>
                </div>
              </div>
            </a>
    
            
            <a href="tela_anotacoes_excluidas.php" class="caderno" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px; color: #ffffff;">
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 0px; margin-right: 4px; width: calc(100% - 18px);">
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: #ffffff; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: #ffffff; flex-shrink: 0;"></svg>
                  </div>
                  <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis; color: #ffffff;">
                  <i class="trash icon" style="color: #ffffff;"></i> Lixeira

                  </div>
                </div>
              </div>
            </a>

            


            <a href="tela_sobre_nos.php" class="caderno" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px; color: #ffffff;">
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 0px; margin-right: 4px; width: calc(100% - 18px);">
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: #ffffff; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: #ffffff; flex-shrink: 0;"></svg>
                  </div>
                  <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis; color: #ffffff;">
                  <i class="user icon" style="color: #ffffff;"></i> Sobre nós
                  </div>
                </div>
              </div>
            </a>

            <div class="wrapper">
             <li class="add-box">
                <div class="icon"><i class="uil uil-plus"></i></div>
                <p>Adicione uma nota</p>
             </li>
            </div>

            <div class="wrapper">
             <li class="add-book">
                <div class="icon"><i class="uil uil-plus"></i></div>
                <p>Crie um caderno</p>
             </li>
            </div>

            <a href="index.php" class="caderno" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px; color: #ffffff; margin-top: 26px;">
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 0px; margin-right: 4px; width: calc(100% - 18px);">
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: #ffffff; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: #ffffff; flex-shrink: 0;"></svg>
                  </div>
                  <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis; color: #ffffff;">
                  <i class="delete icon" style="color: #ffffff;"></i> Sair
                  </div>
                </div>
              </div>
            </a>



        </div>

         </div>
		 
		 

  <div class="popup-box">
      <div class="popup">
        <div class="content">
          <header>
            <p></p>
            <i class="uil uil-times"></i>
          </header>
		  
          <form method="post" action="tela_anotacoes.php?act=cadastrar" id="anotacoes" enctype="multipart/form-data">  
            <div class="row title">
              <label>Título</label>
              <input type="text" name="titulo" spellcheck="false">
            </div>
            <div class="row description">
              <label >Descrição</label>
              <input type="file" name="file" id="fileInput" accept="image/*">
              <img id="selectedImage" style="display: none; max-width: 100px; max-height: 100px;">
              <br>
              <textarea spellcheck="false" id="descriptionTextarea" name="texto" ></textarea>
            </div>
            <button name="cadastrar" onclick="enviar()";>Pronto!</button>
            <p></p>
            
      


          </form>
		  
        </div>
      </div>
	  
    </div>


    
    
	
	<div class="wrapper" style="margin-left:25%; margin-top: -50%; ">
  
		<?php
			$tabela = new ParseQuery("Nota");
			$tabela->equalTo("excluido", "0");
			$tabela->equalTo("email", $_SESSION['email']);	


			$tabela->each(function($obj) {
		?>		
    
    
		<li class="nota">
			<div class="details">
				<p><?php echo $obj->titulo; ?></p>
				<span><?php echo $obj->texto; ?></span>
				<div><img src="<?php echo $obj->foto->getURL(); ?>" width="100dp" height="100dp" /></div>
			</div>
			<div class="bottom-content">
				<span><?php echo $obj->data; ?></span>
				<div class="settings">
					<i onclick="showMenu(this)" class="uil uil-ellipsis-h" style="margin: 30px;"></i>
					<ul class="menu">
					
						<li onclick="updateNote('<?php echo $obj->getObjectId(); ?>')"><i class="uil uil-pen"></i>Editar</li>
						<li onclick="deletar('<?php echo $obj->getObjectId() ?>')"><i class="uil uil-trash"></i>Delete</li>
						
					</ul>
				</div>
			</div>
		</li>

    

    
		<?php
			})
		?>

    
    
      <?php
        $tabela = new ParseQuery("Nota");
        $tabela->equalTo("celular", "1");
        $tabela->equalTo("excluido", "0");



        $tabela->each(function($obj){
      ?>
      
        <?php
        })
       ?>

     

       
  
  <script src="https://kit.fontawesome.com/7b7cd02c9e.js" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="js/anotaçao.js"></script>
</body>
</html>



























