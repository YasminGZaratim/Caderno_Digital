// Obtém a hora atual do sistema
const horaAtual = new Date().getHours();

// Inicializa uma variável para armazenar a mensagem
let mensagem;

// Verifica a hora e define a mensagem apropriada
if (horaAtual >= 5 && horaAtual < 12) {
    mensagem = "Bom Dia!";
} else if (horaAtual >= 12 && horaAtual < 18) {
    mensagem = "Boa Tarde!";
} else {
    mensagem = "Boa Noite!";
}

// Exibe a mensagem na página HTML
document.getElementById("saudacao").textContent = mensagem;
