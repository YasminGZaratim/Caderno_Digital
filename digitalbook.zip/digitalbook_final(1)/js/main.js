import App from "js/App.js";

const root = document.getElementById("app");
const app = new App(root);
