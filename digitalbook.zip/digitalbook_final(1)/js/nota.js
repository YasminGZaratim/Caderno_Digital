// Função para atualizar o título da página e salvar no localStorage
function atualizarTitulo() {
    var novoTitulo = document.querySelector('h1').textContent;
    document.getElementById('tituloPagina').textContent = novoTitulo;
    // Salva o novo título no localStorage
    localStorage.setItem('userTitle', novoTitulo);
}

// Função para restaurar o título do usuário do localStorage ao carregar a página
function restaurarTitulo() {
    var userTitle = localStorage.getItem('userTitle');
    if (userTitle) {
        document.querySelector('h1').textContent = userTitle;
        document.getElementById('tituloPagina').textContent = userTitle;
    }
}

// Função para atualizar a área de texto e salvar no localStorage
function atualizarTexto() {
    var novoTexto = document.querySelector('textarea').value;
    localStorage.setItem('userText', novoTexto);
}

// Função para restaurar o texto do usuário da área de texto ao carregar a página
function restaurarTexto() {
    var userText = localStorage.getItem('userText');
    if (userText) {
        document.querySelector('textarea').value = userText;
    }
}

// Chama as funções de restauração ao carregar a página
window.onload = function() {
    restaurarTitulo();
    restaurarTexto();
};

function adicionarAnotacao(){
    //gera uma chave única para identificar a anotação 
    var chaveAnotacao = 'anotacao_' + Date.now();
    //salva a chave da anotação no localStorage
    localStorage.setItem(chaveAnotacao, novoTitulo);
}

function autoResize(textarea) {
    var style = window.getComputedStyle(textarea, null);
  
    textarea.style.height = 'auto';
    textarea.style.overflow = 'hidden';
  
    // Defina a altura para a altura de conteúdo real ou para uma altura mínima
    var newHeight = Math.max(textarea.scrollHeight, parseInt(style.getPropertyValue('min-height')));
    textarea.style.height = newHeight + 'px';
  
    // Ative a rolagem horizontal se a largura do conteúdo exceder a largura da textarea
    textarea.style.overflowX = textarea.scrollWidth > textarea.clientWidth ? 'auto' : 'hidden';
  }
  
  // Execute a função para redimensionar a textarea no carregamento da página
  autoResize(document.getElementById('textarea'));

  document.querySelector('.anotacao').addEventListener('click', function() {
    // Crie um novo elemento de nota
    var newNote = document.createElement('div');
    newNote.classList.add('notes__list-item', 'notes__list-item--selected');
    
    // Defina o conteúdo inicial da nova nota
    newNote.innerHTML = `
      <div class="notes__small-title">Nova Anotação</div>
      <div class="notes__small-body">Escreva algo aqui...</div>
      <div class="notes__small-updated">${new Date().toLocaleString('pt-BR')}</div>
    `;
    
    // Insira a nova nota após a "Lixeira"
    var lixeira = document.querySelector('.lixeira');
    lixeira.parentNode.insertBefore(newNote, lixeira.nextSibling);
  
    // Salve os dados da nova nota
    saveData();
  
    // Abra a área de edição da nova nota
    openNoteEditor(newNote);
  
    // Adicione um ouvinte de eventos à nova nota para edição posterior
    newNote.addEventListener('click', function() {
      openNoteEditor(newNote);
    });
  });

  // Função para salvar as notas e valores da página
function saveData() {
    // Salve as notas
    localStorage.setItem('userNotes', JSON.stringify(allNotes));
  
    // Salve o título e o corpo da página
    const titleInput = document.getElementById('titleInput');
    const bodyTextarea = document.getElementById('bodyTextarea');
    localStorage.setItem('userTitle', titleInput.value);
    localStorage.setItem('userBody', bodyTextarea.value);
  }
  
  
  
  
    
  
  