const sairLink = document.getElementById('sairLink');

sairLink.addEventListener('click', function (e) {
    e.preventDefault();

    const confirmacao = confirm('Tem certeza de que deseja sair?');

    if (confirmacao) {
        // Redirecionar para index.html
        window.location.href = 'index.html';
    }
});
