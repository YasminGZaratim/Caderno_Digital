// Função para exibir a data e hora de última edição com horas, minutos e segundos
function exibirDataVisto() {
    const dataVisto = new Date(); // Obtenha a data e hora atuais
    const elementoData = document.getElementById('dataVisto');

    // Formate a data e hora como "dd/mm/aaaa hh:mm:ss"
    const dataFormatada = `${dataVisto.toLocaleDateString()} ${dataVisto.toLocaleTimeString()}`;

    // Defina a data e hora no elemento HTML
    elementoData.textContent = dataFormatada;
}

// Chame a função para exibir a data e hora de última edição quando a página for carregada
window.addEventListener('load', exibirDataVisto);
// Chame a função para atualizar a data e hora de última edição quando o botão "Editar" for clicado
document.getElementById('botaoEditar').addEventListener('click', atualizarDataVisto);

// Função para exibir a data e hora de última edição com horas, minutos e segundos
function exibirDataVisto2() {
    const dataVisto2 = new Date(); // Obtenha a data e hora atuais
    const elementoData = document.getElementById('dataVisto2');

    // Formate a data e hora como "dd/mm/aaaa hh:mm:ss"
    const dataFormatada = `${dataVisto2.toLocaleDateString()} ${dataVisto2.toLocaleTimeString()}`;

    // Defina a data e hora no elemento HTML
    elementoData.textContent = dataFormatada;
}

// Chame a função para exibir a data e hora de última edição quando a página for carregada
window.addEventListener('load', exibirDataVisto2);

// Função para exibir a data e hora de última edição com horas, minutos e segundos
function exibirDataVisto3() {
    const dataVisto3 = new Date(); // Obtenha a data e hora atuais
    const elementoData = document.getElementById('dataVisto3');

    // Formate a data e hora como "dd/mm/aaaa hh:mm:ss"
    const dataFormatada = `${dataVisto3.toLocaleDateString()} ${dataVisto3.toLocaleTimeString()}`;

    // Defina a data e hora no elemento HTML
    elementoData.textContent = dataFormatada;
}

// Chame a função para exibir a data e hora de última edição quando a página for carregada
window.addEventListener('load', exibirDataVisto3);

// Função para exibir a data e hora de última edição com horas, minutos e segundos
function exibirDataVisto4() {
    const dataVisto4 = new Date(); // Obtenha a data e hora atuais
    const elementoData = document.getElementById('dataVisto4');

    // Formate a data e hora como "dd/mm/aaaa hh:mm:ss"
    const dataFormatada = `${dataVisto4.toLocaleDateString()} ${dataVisto4.toLocaleTimeString()}`;

    // Defina a data e hora no elemento HTML
    elementoData.textContent = dataFormatada;
}

// Chame a função para exibir a data e hora de última edição quando a página for carregada
window.addEventListener('load', exibirDataVisto4);

// Função para exibir a data e hora de última edição com horas, minutos e segundos
function exibirDataVisto5() {
    const dataVisto5 = new Date(); // Obtenha a data e hora atuais
    const elementoData = document.getElementById('dataVisto5');

    // Formate a data e hora como "dd/mm/aaaa hh:mm:ss"
    const dataFormatada = `${dataVisto5.toLocaleDateString()} ${dataVisto5.toLocaleTimeString()}`;

    // Defina a data e hora no elemento HTML
    elementoData.textContent = dataFormatada;
}

// Chame a função para exibir a data e hora de última edição quando a página for carregada
window.addEventListener('load', exibirDataVisto5);

// Função para exibir a data e hora de última edição com horas, minutos e segundos
function exibirDataVisto6() {
    const dataVisto6 = new Date(); // Obtenha a data e hora atuais
    const elementoData = document.getElementById('dataVisto6');

    // Formate a data e hora como "dd/mm/aaaa hh:mm:ss"
    const dataFormatada = `${dataVisto6.toLocaleDateString()} ${dataVisto6.toLocaleTimeString()}`;

    // Defina a data e hora no elemento HTML
    elementoData.textContent = dataFormatada;
}

// Chame a função para exibir a data e hora de última edição quando a página for carregada
window.addEventListener('load', exibirDataVisto6);

// Função para exibir a data e hora de última edição com horas, minutos e segundos
function exibirDataVisto7() {
    const dataVisto7 = new Date(); // Obtenha a data e hora atuais
    const elementoData = document.getElementById('dataVisto7');

    // Formate a data e hora como "dd/mm/aaaa hh:mm:ss"
    const dataFormatada = `${dataVisto7.toLocaleDateString()} ${dataVisto7.toLocaleTimeString()}`;

    // Defina a data e hora no elemento HTML
    elementoData.textContent = dataFormatada;
}

// Chame a função para exibir a data e hora de última edição quando a página for carregada
window.addEventListener('load', exibirDataVisto7);

// Função para exibir a data e hora de última edição com horas, minutos e segundos
function exibirDataVisto8() {
    const dataVisto8 = new Date(); // Obtenha a data e hora atuais
    const elementoData = document.getElementById('dataVisto8');

    // Formate a data e hora como "dd/mm/aaaa hh:mm:ss"
    const dataFormatada = `${dataVisto8.toLocaleDateString()} ${dataVisto8.toLocaleTimeString()}`;

    // Defina a data e hora no elemento HTML
    elementoData.textContent = dataFormatada;
}

// Chame a função para exibir a data e hora de última edição quando a página for carregada
window.addEventListener('load', exibirDataVisto8);

// Função para exibir a data e hora de última edição com horas, minutos e segundos
function exibirDataVisto9() {
    const dataVisto9 = new Date(); // Obtenha a data e hora atuais
    const elementoData = document.getElementById('dataVisto9');

    // Formate a data e hora como "dd/mm/aaaa hh:mm:ss"
    const dataFormatada = `${dataVisto9.toLocaleDateString()} ${dataVisto9.toLocaleTimeString()}`;

    // Defina a data e hora no elemento HTML
    elementoData.textContent = dataFormatada;
}

// Chame a função para exibir a data e hora de última edição quando a página for carregada
window.addEventListener('load', exibirDataVisto9);