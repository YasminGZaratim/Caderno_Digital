<?php
require 'autoload.php';
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseACL;
use Parse\ParsePush;
use Parse\ParseUser;
use Parse\ParseInstallation;
use Parse\ParseException;
use Parse\ParseAnalytics;
use Parse\ParseFile;
use Parse\ParseCloud;
use Parse\ParseClient;
$app_id='KxaEmPPcjtpdi2dpvY6FZ41PPZbvmucoNgcwUQNw';
$rest_key='swcBixrt6EvNMu2H2ElfcaXF6avPsmheO0VV6pNQ';
$master_key='ZDtk0mNobUSSEFytF5lCo10HCRuqRzvx2O86okZ6';
ParseClient::initialize( $app_id, $rest_key, $master_key );
// Users of Parse Server will need to point ParseClient at their remote URL and Mount Point:
ParseClient::setServerURL('https://parseapi.back4app.com','/');
ParseClient::setCAFile(__DIR__ . '/certs/cacert.pem');

if (isset($_GET["act"])){	
	$email = $_GET['email'];
	$senha = $_GET['senha'];
	
	$object = ParseObject::create("Usuario");

	$object->set("email", $email);
	$object->set("senha", $senha);
	$object->save();
	
	header('Location: index.php');
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastre-se</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="css/signin.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css" rel="stylesheet">
</head>
<body style="background-color: #efedec">
    
  <form class="form-signin">
    
    <input type="email" id="inputEmail" class="form-control" placeholder="Email" required autofocus style="background: #b6b2ac; border-radius: 86px">
    <p></p>
    <input type="password" id="inputSenha" class="form-control" placeholder="Senha" required autofocus style="background: #b6b2ac; border-radius: 86px">
    <input type="password" id="inputConfSenha" class="form-control" placeholder="Confirmar senha" required autofocus style="background: #b6b2ac; border-radius: 86px">
    <a class="btn btn-lg btn-primary btn-block" type="submit" style="background: #51524a; border-radius: 86px;"   onclick="alert()">CRIAR CONTA</a>

    <a href="index.php" style="position: absolute; top: 77%; left: 50%; transform: translate(-50%, -50%); "> Já possui uma conta? Entre aqui!</a>

    

      </form>

    <p class="mt-5 mb-3 text-muted" style="position:absolute; top: 79%; left: 50%; transform: translate(-50%, -50%);">&copy; since 2023</p>
  </form>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <script>
    function alert() {
      const email = document.getElementById('inputEmail').value;
      const senha = document.getElementById('inputSenha').value;
      const confirmarSenha = document.getElementById('inputConfSenha').value;
      
        if (!email || !validarEmail(email) || !senha || !validarSenha(senha)) {
          // Exibir mensagem de erro
          Swal.fire({
            title: 'Erro',
            text: 'Por favor, insira um email ou senha válidos.',
            icon: 'error',
            confirmButtonText: 'Ok'
          });
        } else {
          if (senha.length < 8) {
                    Swal.fire({
                    title: 'Erro',
                    text: 'A nova senha deve ter pelo menos 8 caracteres.',
                    icon: 'error',
                    confirmButtonText: 'Ok'
                    });
                return;
                }

                if (senha != confirmarSenha) {
                    Swal.fire({
                    title: 'Erro',
                    text: 'Senhas não coincidem.',
                    icon: 'error',
                    confirmButtonText: 'Ok'
                    });
                return;
                } else{
                  // Email e senha e confSenha são válidos, mostrar mensagem de boas-vindas
                  Swal.fire({
                  title: 'Bem-vindo(a)!',
                  icon: 'success',
                  confirmButtonText: 'Continuar'
               }).then((result) => {
                    if (result.isConfirmed) {
                    // Redirecionar o usuário para tela_anotacoes.html
                    window.location.href = 'tela_cadastrar.php?act=ok&email='+email+'&senha='+senha;
            }
          });
                }
        }
        
      }
      
      function validarEmail(email) {
      const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return regexEmail.test(email);
    }
      
    function validarSenha(senha) {
    return senha.length >= 8;
    }
</script>
</body>

</html>


