<?php
require 'autoload.php';
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseACL;
use Parse\ParsePush;
use Parse\ParseUser;
use Parse\ParseInstallation;
use Parse\ParseException;
use Parse\ParseAnalytics;
use Parse\ParseFile;
use Parse\ParseCloud;
use Parse\ParseClient;
$app_id='KxaEmPPcjtpdi2dpvY6FZ41PPZbvmucoNgcwUQNw';
$rest_key='swcBixrt6EvNMu2H2ElfcaXF6avPsmheO0VV6pNQ';
$master_key='ZDtk0mNobUSSEFytF5lCo10HCRuqRzvx2O86okZ6';
ParseClient::initialize( $app_id, $rest_key, $master_key );
ParseClient::setServerURL('https://parseapi.back4app.com','/');
ParseClient::setCAFile(__DIR__ . '/certs/cacert.pem');


//Se clicou em cadastrar
if (isset($_REQUEST['act'])){
	
	//Pego os dados do formulário
	$titulo = $_REQUEST['titulo'];
	$texto = $_REQUEST['texto'];

	//echo "titulo: ".$titulo;
	//exit();

	
	$tabela = ParseObject::create("Nota");
	
		
	$file = ParseFile::createFromData(file_get_contents($_FILES["file"]["tmp_name"]), $_FILES["file"]["name"]);
	$file->save();
	
	$tabela->set("titulo", $titulo);
	$tabela->set("texto", $texto);
	$tabela->set("foto", $file);
	$tabela->save();
}
?>
<!-- <!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bem-vindo</title>
    <link href="../../dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="navbar.css" rel="stylesheet">
    <link href="navbar-top-fixed.css" rel="stylesheet">
     <link href="album.css" rel="stylesheet">
     
</head>
<body>
    <nav class="navbar navbar-light fixed-top"  style="background-color: #2c8694"> 
        
      </form>
      
      <a href="tela_anotacoes.html" class="mr-auto">
        <img style="width: 100px;" src="imagens/logo_original(8).png"/>
      </a>

        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Pesquise suas anotações" aria-label="Pesquise suas anotações" style="border-radius: 86px; background-color: #f1f1ed" >
          
        </form>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample01" aria-controls="navbarsExample01" aria-expanded="false" aria-label="Toggle navigation">
           
            <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse" id="navbarsExample01">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="tela_config_conta.html">Configuração da Conta<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="tela_sobre.html">Sobre</a>
            </li>
            
        
            <li class="nav-item active">
              <div id="alertaModal" class="modal">
                <div class="modal-content">
                    <p>Tem certeza de que deseja sair?</p>
                    <button id="sair">Sair</button>
                    <button id="cancelar">Cancelar</button>
                </div>
            </div>
        
                </form>
            <a class="nav-link" href="index.html" id="sairLink">Sair</a>
            
            </li>
       
      </nav>
      
      <div class="album py-5 " style="background-color: #f1f1ed;">
        <div class="container">
          <div class="col-sm-8 col-md-7 py-4">
            <h2 id="saudacao"></h2>
        
             Inclui o arquivo JavaScript 
            <script src="saudacao.js"></script>
          <br>
          </div>
          <div class="row">
            
            <div class="col-md-4">
           
              <div class="card mb-4 shadow-sm">
               
                <img class="card-img-top" src="imagens/icon_caderno.png">
                <div class="card-body">
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <a type="button" class="btn btn-sm btn-outline-secondary" href="tela_nota.html" >Ver</a>
                      <button type="button" class="btn btn-sm btn-outline-secondary" id="botaoEditar">Editar</button>
                    </div>
                    <p><small class="text-muted" id="dataVisto9"></small></p>
                    <script src="vistoporultimo.js"></script>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="imagens/icon_caderno.png" >
                <div class="card-body">
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <a type="button" class="btn btn-sm btn-outline-secondary" href="tela_nota.html" >Ver</a>
                      <button type="button" class="btn btn-sm btn-outline-secondary">Editar</button>
                    </div>
                    <p><small class="text-muted" id="dataVisto8"></small></p>
                    <script src="vistoporultimo.js"></script>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="imagens/icon_caderno.png">
                <div class="card-body">
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-sm btn-outline-secondary">Ver</button>
                      <button type="button" class="btn btn-sm btn-outline-secondary">Editar</button>
                    </div>
                    <p><small class="text-muted" id="dataVisto7"></small></p>
                    <script src="vistoporultimo.js"></script>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="imagens/icon_caderno.png">
                <div class="card-body">
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-sm btn-outline-secondary">Ver</button>
                      <button type="button" class="btn btn-sm btn-outline-secondary">Editar</button>
                    </div>
                    <p><small class="text-muted" id="dataVisto6"></small></p>
                    <script src="vistoporultimo.js"></script>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="imagens/icon_caderno.png">
                <div class="card-body">
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-sm btn-outline-secondary">Ver</button>
                      <button type="button" class="btn btn-sm btn-outline-secondary">Editar</button>
                    </div>
                    <p><small class="text-muted" id="dataVisto5"></small></p>
                    <script src="vistoporultimo.js"></script>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="imagens/icon_caderno.png">
                <div class="card-body">
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-sm btn-outline-secondary">Ver</button>
                      <button type="button" class="btn btn-sm btn-outline-secondary">Editar</button>
                    </div>
                    <p><small class="text-muted" id="dataVisto4"></small></p>
                    <script src="vistoporultimo.js"></script>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="imagens/icon_caderno.png">
                <div class="card-body">
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-sm btn-outline-secondary">Ver</button>
                      <button type="button" class="btn btn-sm btn-outline-secondary">Editar</button>
                    </div>
                    <p><small class="text-muted" id="dataVisto3"></small></p>
                    <script src="vistoporultimo.js"></script>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="imagens/icon_caderno.png">
                <div class="card-body">
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-sm btn-outline-secondary">Ver</button>
                      <button type="button" class="btn btn-sm btn-outline-secondary">Editar</button>
                    </div>
                    <p><small class="text-muted" id="dataVisto2"></small></p>
                    <script src="vistoporultimo.js"></script>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="imagens/icon_caderno.png">
                <div class="card-body">
                  <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <button type="button" class="btn btn-sm btn-outline-secondary" id="botaoVer">Ver</button>
                      <button type="button" class="btn btn-sm btn-outline-secondary" id="botaoEditar">Editar</button>
                    </div>
                    <p><small class="text-muted" id="dataVisto"></small></p>
                    <script src="vistoporultimo.js"></script>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    
  
</div>
      <script src="alertaConfCancel.js"></script>
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html> -->


<!-- <!DOCTYPE html>
<html>
<head>
    <title>Menu Inspirado no Notion</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }

        #menu {
            background-color: #333;
            color: #fff;
            width: 150px; /* Largura do menu */
            height: 929px; /* Aumenta a altura do menu */
            padding: 20px;
        }

        #menu h1 {
            font-size: 24px;
        }

        #menu ul {
            list-style: none;
            padding: 0;
        }

        #menu ul li {
            font-size: 18px;
            cursor: pointer;
        }

        #menu ul li:hover {
            text-decoration: underline;
        }

        #page-content {
            padding: 20px;
        }
    </style>
</head>
<body>
    <div id="menu">
        <h1>Meu Notion</h1>
        <ul>
            <li>Página Inicial</li>
            <li>Notas</li>
            <li>Tarefas</li>
            <li>Calendário</li>
        </ul>
    </div>
    <div id="page-content">
         Conteúdo da página vai aqui 
        <h2>Bem-vindo ao Meu Notion</h2>
        <p>Aqui você pode criar, editar e organizar suas notas e tarefas.</p>
    </div>
</body>
</html> -->


<!-- <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE: edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.17.4/dist/css/uikit.min.css" />
  <title>Document</title>
</head>
<body>

<div id="offcanvas-nav" uk-offcanvas="overlay: true">
    <div class="uk-offcanvas-bar">
      
       <a class="uk-button uk-button-default" type="button" uk-toggle="target: #offcanvas-nav"> <span class="uk-margin-small-right" uk-icon="icon: table"></span>Menu</a> 
       <div class="ui black big launch right attached fixed button">
            <i class="content icon"></i>
            <span class="text">Menu</span>
        </div>
        <ul class="uk-nav uk-nav-default">
            <li class="uk-active"><a href="#">Active</a></li>
            <li class="uk-parent">
                <a href="#">Parent</a>
                <ul class="uk-nav-sub">
                    <li><a href="#">Sub item</a></li>
                    <li><a href="#">Sub item</a></li>
                </ul>
            </li>
            <li class="uk-nav-header">Header</li>
            <li><a href="#"><span class="uk-margin-small-right" uk-icon="icon: table"></span> Item</a></li>
            <li><a href="#"><span class="uk-margin-small-right" uk-icon="icon: thumbnails"></span> Item</a></li>
            <li class="uk-nav-divider"></li>
            <li><a href="#"><span class="uk-margin-small-right" uk-icon="icon: trash"></span> Item</a></li>
        </ul>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/uikit@3.17.4/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@3.17.4/dist/js/uikit-icons.min.js"></script>
<script>
    // JavaScript para mostrar o menu ao carregar a página
    UIkit.offcanvas('#offcanvas-nav').show();
</script>
</body>
</html> -->



<!-- <!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
</head>
<body>
  <div class="ui vertical sidebar menu">
    <a class="item">Home</a>
    <a class="item">Products</a>
    <a class="item">Services</a>
    <a class="item">About</a>
  </div>

  <div class="pusher">
    <button id="showSidebar" class="ui primary basic button">
      <i class="table icon"></i>
    </button>
    <div class="ui container">
      Conteúdo da página
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#showSidebar').click(function() {
        $('.ui.sidebar').sidebar('toggle');
      });
    });
  </script>
</body>
</html> -->

<!-- <!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
  <style>
    body, html {
      height: 100%;
    }

    .ui.vertical.menu {
      height: 100%;
    }

    .fixed-button {
      position: fixed;
      top: 20px;
      left: 20px;
      z-index: 1000;
    }
  </style>
</head>
<body>
 
  </div>

  <div class="pusher">
    <a href="#"><span class="ui secondary button" uk-icon="icon: table" id="showSidebar"></span></a>
    
    <div class="ui left vertical inverted sidebar menu">
      <a class="item">
        <i class="home icon"></i>
        Home
      </a>
      <a class="item">
        <i class="table icon"></i>
        Products
      </a>
      
      <a class="item">
        <i class="info icon"></i>
        About
      </a>
    </div>
    <div class="ui container">
      Conteúdo da página 
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#showSidebar').click(function() {
        $('.ui.sidebar').sidebar('toggle');
      });
    });
  </script>
</body>
</html> -->


<!-- <!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
  <style>
    body, html {
      height: 100%;
    }

    .ui.vertical.menu {
      height: 100%;
    }

    .fixed-button {
      position: fixed;
      top: 20px;
      left: 20px;
      z-index: 1000;
    }

    .square-button {
      width: 50px; /* Aumenta um pouco a largura */
      height: 50px; /* Aumenta um pouco a altura */
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .square-button i.bars.icon {
      font-size: 25px; /* Aumenta o tamanho do ícone */
      line-height: 27px; /* Centraliza verticalmente o ícone */
      
    }
  </style>
</head>
<body>
  <div class="pusher">
    <a href="#">
      <span class="ui secondary button square-button" uk-icon="icon: table" id="showSidebar">
        <i class="bars icon"></i>
      </span>
    </a>
  </div>

  <div class="ui left vertical inverted sidebar menu">
    <a class="item">
      <i class="home icon"></i>
      Home
    </a>
    <a class="item">
      <i class="table icon"></i>
      Products
    </a>
    
    <a class="item">
      <i class="info icon"></i>
      About
    </a>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#showSidebar').click(function() {
        $('.ui.sidebar').sidebar('toggle');
      });
    });
  </script>
</body>
</html> -->

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE-edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
  <link rel="stylesheet" href="css/nota.css">
  <link rel="icon" href="imagens/logo_original(8).png"style="width:1000px" type="image/x-icon">
  <title id="tituloPagina"> Digital Book </title>
  
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
<body class="dark-mode">
  <!-- Seu conteúdo aqui -->
  <div class="notes" id="app">
    <div class="notes__sidebar">
      <div class="container">
        

           

         

            
            <img style="width: 120px; display: block; margin: 0 auto;" src="imagens/logo_original(8).png"/>

            <!--Barra de pesquisa -->
          <div class="pesquisa" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px;">
            
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 4px; margin-right: -30px; width: calc(100% - 8px);">
              
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: rgba(55, 53, 47, 0.65); width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                  
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: rgba(55, 53, 47, 0.45); flex-shrink: 0;">

                    </svg>
                  
                  </div>

                    <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis;">
                    
                          <i class="search icon " style="color: #ffffff; left:-30px"></i>Pesquisar
                        
                      
                    </div>
                
                </div>

              </div> 

            </div>


             
          
           
            <a href="tela_config_conta.php" class="configuracao" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px;">
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 0px; margin-right: 4px; width: calc(100% - 18px);">
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: #ffffff; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: #ffffff; flex-shrink: 0;"></svg>
                  </div>
                  <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis; color: #ffffff;">
                    <i class="configure icon" style="color: #ffffff;"></i>Configurações
                  </div>
                </div>
              </div>
            </a>
    
            <!-- Criar novo caderno -->
            <a href="tela_criar_novo_caderno.php" class="caderno" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px; color: #ffffff;">
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 0px; margin-right: 4px; width: calc(100% - 18px);">
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: #ffffff; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: #ffffff; flex-shrink: 0;"></svg>
                  </div>
                  <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis; color: #ffffff;">
                    <i class="book icon" style="color: #ffffff;"></i>Criar novo caderno
                  </div>
                </div>
              </div>
            </a>
          


            
      
            <div class="lixeira" style="flex-grow: 0; flex-shrink: 0; padding-bottom: 8px;">
            
              <div role="button" tabindex="0" style="user-select: none; transition: background 20ms ease-in 0s; cursor: pointer; border-radius: 3px; margin-left: 4px; margin-right: 4px; width: calc(100% - 8px);">
              
                <div style="display: flex; align-items: center; width: 100%; font-size: 14px; min-height: 27px; padding: 2px 10px; margin-top: 1px; margin-bottom: 1px;">
                
                  <div style="flex-shrink: 0; flex-grow: 0; border-radius: 4px; color: rgba(55, 53, 47, 0.65); width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; margin-right: 8px;">
                  
                    <svg role="graphics-symbol" viewBox="0 0 20 20" class="sidebarSearch" style="width: 20px; height: 100%; display: block; fill: rgba(55, 53, 47, 0.45); flex-shrink: 0;">

                    </svg>
                  
                  </div>

                    <div class="hover" style="flex: 1 1 auto; white-space: nowrap; min-width: 0px; overflow: hidden; text-overflow: ellipsis;">
                    
                      <i class="trash icon"></i>Lixeira
                        
                      
                    </div>
                
                </div>

              </div> 

            </div>  


             



        </div>

         </div>
          <!-- Conteúdo Principal -->
    <!--<div class="main-content">
      <div id="container">
          <h1 id="tituloPagina" contenteditable="true" oninput="atualizarTitulo()" onmouseover="mostrarAdicionarCapa()">Sem título</h1>
          <div id="opcaoAdicionar">
              <label id="fileLabel" for="fileInput">
                  <img style="width:20px; height: 25px; top:60px" src="imagens/icone_foto.jpg" alt="Câmera" id="cameraIcon">
                  Adicionar Capa
              </label>
              <input type="file" id="fileInput" style="display:none;" onchange="handleFileSelect(event)">
          </div>
      </div>
      <div class="container">
          <textarea contenteditable="true" oninput="autoResize(this); atualizarTexto();" placeholder="Digite seu texto aqui..." id="textarea"></textarea>
      </div>
      <div class="results"></div>
  </div>-->

  <div class="popup-box">
      <div class="popup">
        <div class="content">
          <header>
            <p></p>
            <i class="uil uil-times"></i>
          </header>
		  
          <form method="post" action="tela_anotacoes.php?act=cadastrar" id="anotacoes" enctype="multipart/form-data">  
            <div class="row title">
              <label>Título</label>
              <input type="text" name="titulo" spellcheck="false">
            </div>
            <div class="row description">
              <label >Descrição</label>
              <input type="file" name="file" id="fileInput" accept="image/*">
              <img id="selectedImage" style="display: none; max-width: 100px; max-height: 100px;">
              <br>
              <textarea spellcheck="false" id="descriptionTextarea" name="texto" ></textarea>
            </div>
            <button name="cadastrar" onclick="enviar()";>Pronto!</button>
            <p></p>
            
            <div class="row">
            <button id="addPhoto">Adicionar uma foto</button>
            </div>
          </form>
		  
        </div>
      </div>
    </div>
    <div class="wrapper">
      <li class="add-box">
        <div class="icon"><i class="uil uil-plus"></i></div>
        <p>Adicione uma nova nota</p>
      </li>
    </div>

  </script>-->
  <!--<script src="js/anotaçao.js"></script>-->
  <style>
    body {
      font-family: 'Arial', sans-serif;
      margin: 0;
      padding: 0;
    }
  
    .notes__sidebar {
      background-color: #88ABFF;
      color: #ecf0f1;
      padding: 20px;
      width: 23%;
    }
  
    .logo {
      display: block;
      margin: 0 auto;
    }
  
    /*.search-bar {
      background-color: #195052;
      border-radius: 5px;
      padding: 8px;
      margin-top: 10px;
    }/*
  
    .search-icon {
      color: #ecf0f1;
    }
  
    .config-link,
    .note-link,
    .trash-link {
      color: #ecf0f1;
      text-decoration: none;
      display: block;
      margin-top: 15px;
    }
  
    .config-link:hover,
    .note-link:hover,
    .trash-link:hover {
      color: #3498db;
    }
  
    /* Estilos para a barra de pesquisa */
.pesquisa {
  display: flex;
  align-items: center;
  padding: 4px;
  margin: 0 4px;
  border-radius: 3px;
  background-color: #4c80fc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/*.pesquisa button {
  user-select: none;
  transition: background 20ms ease-in 0s;
  cursor: pointer;
  border-radius: 30px;
  margin-left: 4px;
  margin-right: -30px;
  width: calc(100% - 8px);
  background-color: #fff;
}*/

.pesquisa:hover {
  background-color: #0f4ad9;
}

.configuracao{
  display: flex;
  align-items: center;
  padding: 4px;
  margin: 0 4px;
  border-radius: 3px;
  background-color: #4c80fc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-top: 10px;
}

.configuracao:hover {
  background-color: #0f4ad9;
}

.caderno{
  display: flex;
  align-items: center;
  padding: 4px;
  margin: 0 4px;
  border-radius: 3px;
  background-color: #4c80fc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-top: 10px;
}

.caderno:hover{
  background-color: #0f4ad9;
}
.lixeira{
  display: flex;
  align-items: center;
  padding: 4px;
  margin: 0 4px;
  border-radius: 3px;
  background-color: #4c80fc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-top: 10px;
}

.lixeira:hover{
  background-color: #0f4ad9;

}

/*.pesquisa .icon-container {
  flex-shrink: 0;
  flex-grow: 0;
  border-radius: 40px;
  color: rgba(55, 53, 47, 0.65);
  width: 16px;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 4px;
  background-color: #ccc;
}

.pesquisa .icon-container svg {
  width: 14px;
  height: 100%;
  display: block;
  fill: rgba(55, 53, 47, 0.45);
  flex-shrink: 0;
}

/*.pesquisa .hover {
  flex: 1 1 auto;
  white-space: nowrap;
  min-width: 0px;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #ffffff;
}*/

/* Adicionando sombra à barra de pesquisa */
/*.pesquisa {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}*/

/* Posicionando à esquerda */
/*.pesquisa .icon-container,
.pesquisa .hover {
  margin-left: 4px;
}*/

/* Estilos para abas 
.notes .container .pesquisa,
.notes .container .configuracao,
.notes .container .caderno,
.notes .container .anotacao,
.notes .container .lixeira {
  display: flex;
  align-items: center;
  padding-bottom: 8px;
}*/

/*.notes .container a {
  flex-grow: 0;
  flex-shrink: 0;
  transition: background 20ms ease-in 0s;
  cursor: pointer;
  border-radius: 3px;
  margin-left: -30px;
  margin-right: 4px;
  width: calc(100% - 18px);
}

/*.notes .container a:hover {
  background-color: #e0e0e0;
}*/

/*.notes .container a .hover {
  flex: 1 1 auto;
  white-space: nowrap;
  min-width: 0px;
  overflow: hidden;
  text-overflow: ellipsis;
  color: #ffffff;
}

.notes .container a .icon-container {
  flex-shrink: 0;
  flex-grow: 0;
  border-radius: 3px;
  color: #ffffff;
  width: 10px;
  height: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 8px;
  background-color: #161616;
}

.notes .container a .icon-container svg {
  width: 20px;
  height: 100%;
  display: block;
  fill: #ffffff;
  flex-shrink: 0;
}/*
#opcaoAdicionar {
      position: absolute;
      top: 170px;
      left: 554px;
      display: none;
    }

    #container:hover #opcaoAdicionar {
      display: block;
    }
    #tituloPagina {
      margin-right: 20px; /* Ajuste a margem para movê-lo para o lado direito */
    /*  margin-bottom: 10px; /* Ajuste a margem para movê-    margin-top: 170px;
      margin-left: 170px;
    }

    #textarea {
      padding: 10px; 
      margin-left: 170px;
      width: 70%;
            height: 100px; 
      border: none;
    }
    #settings-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background-color: #3498db;
      color: #000000;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      text-align: center;
      line-height: 40px;
      cursor: pointer;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    /* Adicione estilos para o menu de configurações 
    #settings-menu {
      position: fixed;
      bottom: 70px;
      right: 20px;
      background-color: #fff;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      padding: 10px;
      max-width: 150px;
    }

    #settings-menu ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    #settings-menu li {
      cursor: pointer;
      padding: 5px;
    }

    #settings-menu li:hover {
      background-color: #f0f0f0;
    }
    /* Adicione seu CSS para a classe .highlighted-text c
    .highlighted-text {
      background-color: yellow;
      background-color: #3498db;
      background-color: aqua;
    }

    
   
    #settings-menu.hidden {
    display: none;
  }
  #formatting-menu {
      position: fixed;
      bottom: 20px;
      left: 59%;
      transform: translateX(-50%);
      margin-left:35px;
      
      padding: 10px;
      border-radius: 5px;
      box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
      width: 53%;
    }

    #formatting-menu i {
      font-size: 24px;
      margin: 0 10px;
      cursor: pointer;
    }
    #floating-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 50px;
      height: 50px;
      background-color: black;
      color: rgb(0, 0, 0);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background-color 0.3s, color 0.3s;
      color: rgb(0, 0, 0);
    }
    .dark-mode #floating-icon {
  color: white; /* Defina a cor do ícone
    #textarea-container {
      position: fixed;
      bottom: 70px;
      right: 20px;
      background-color: rgb(255, 255, 255); /* C
      color: white;
      padding: 10px;
      border-radius: 10px;
      display: none; /* Oculta inicialmente 
    }*/

    /* Import Google Font - Poppins */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
body{
  background: #88ABFF;
}
::selection{
  color: #fff;
  background: #618cf8;
}
.wrapper {
  margin: 50px;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(265px, 1fr)); /* Isso permite que cada item tenha no mínimo 265px de largura e se expanda para preencher a largura disponível. */
  gap: 25px;
  max-width: 80em; /* Defina a largura máxima desejada que pode acomodar pelo menos 6 itens. */
  
}


.wrapper li{
  height: 250px;
  list-style: none;
  border-radius: 5px;
  padding: 15px 20px 20px;
  background: #fff;
  box-shadow: 0 4px 8px rgba(0,0,0,0.05);
}
.add-box, .icon, .bottom-content, 
.popup, header, .settings .menu li{
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.add-box{
  cursor: pointer;
  flex-direction: column;
  justify-content: center;
}
.add-box .icon{
  height: 78px;
  width: 78px;
  color: #88ABFF;
  font-size: 40px;
  border-radius: 50%;
  justify-content: center;
  border: 2px dashed #88ABFF;
}
.add-box p{
  color: #88ABFF;
  font-weight: 500;
  margin-top: 20px;
}
.note{
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.note .details{
  max-height: 165px;
  overflow-y: auto;
}
.note .details::-webkit-scrollbar,
.popup textarea::-webkit-scrollbar{
  width: 0;
}
.note .details:hover::-webkit-scrollbar,
.popup textarea:hover::-webkit-scrollbar{
  width: 5px;
}
.note .details:hover::-webkit-scrollbar-track,
.popup textarea:hover::-webkit-scrollbar-track{
  background: #f1f1f1;
  border-radius: 25px;
}
.note .details:hover::-webkit-scrollbar-thumb,
.popup textarea:hover::-webkit-scrollbar-thumb{
  background: #e6e6e6;
  border-radius: 25px;
}
.note p{
  font-size: 22px;
  font-weight: 500;
}
.note span{
  display: block;
  color: #575757;
  font-size: 16px;
  margin-top: 5px;
}
.note .bottom-content{
  padding-top: 10px;
  border-top: 1px solid #ccc;
}
.bottom-content span{
  color: #6D6D6D;
  font-size: 14px;
}
.bottom-content .settings{
  position: relative;
}
.bottom-content .settings i{
  color: #6D6D6D;
  cursor: pointer;
  font-size: 15px;
}
.settings .menu{
  z-index: 1;
  bottom: 0;
  right: -5px;
  padding: 5px 0;
  background: #fff;
  position: absolute;
  border-radius: 4px;
  transform: scale(0);
  transform-origin: bottom right;
  box-shadow: 0 0 6px rgba(0,0,0,0.15);
  transition: transform 0.2s ease;
}
.settings.show .menu{
  transform: scale(1);
}
.settings .menu li{
  height: 25px;
  font-size: 16px;
  margin-bottom: 2px;
  padding: 17px 15px;
  cursor: pointer;
  box-shadow: none;
  border-radius: 0;
  justify-content: flex-start;
}
.menu li:last-child{
  margin-bottom: 0;
}
.menu li:hover{
  background: #f5f5f5;
}
.menu li i{
  padding-right: 8px;
}

.popup-box{
  position: fixed;
  top: 0;
  left: 0;
  z-index: 2;
  height: 100%;
  width: 100%;
  background: rgba(0,0,0,0.4);
}
.popup-box .popup{
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 3;
  width: 100%;
  max-width: 400px;
  justify-content: center;
  transform: translate(-50%, -50%) scale(0.95);
}
.popup-box, .popup{
  opacity: 0;
  pointer-events: none;
  transition: all 0.25s ease;
}
.popup-box.show, .popup-box.show .popup{
  opacity: 1;
  pointer-events: auto;
}
.popup-box.show .popup{
  transform: translate(-50%, -50%) scale(1);
}
.popup .content{
  border-radius: 5px;
  background: #fff;
  width: calc(100% - 15px);
  box-shadow: 0 0 15px rgba(0,0,0,0.1);
}
.content header{
  padding: 15px 25px;
  border-bottom: 1px solid #ccc;
}
.content header p{
  font-size: 20px;
  font-weight: 500;
}
.content header i{
  color: #8b8989;
  cursor: pointer;
  font-size: 23px;
}
.content form{
  margin: 15px 25px 35px;
}
.content form .row{
  margin-bottom: 20px;
}
form .row label{
  font-size: 18px;
  display: block;
  margin-bottom: 6px;
}
form :where(input, textarea){
  height: 50px;
  width: 100%;
  outline: none;
  font-size: 17px;
  padding: 0 15px;
  border-radius: 4px;
  border: 1px solid #999;
}
form :where(input, textarea):focus{
  box-shadow: 0 2px 4px rgba(0,0,0,0.11);
}
form .row textarea{
  height: 150px;
  resize: none;
  padding: 8px 15px;
}
form button{
  width: 100%;
  height: 50px;
  color: #fff;
  outline: none;
  border: none;
  cursor: pointer;
  font-size: 17px;
  border-radius: 4px;
  background: #6A93F8;
}

@media (max-width: 660px){
  .wrapper{
    margin: 15px;
    gap: 15px;
    grid-template-columns: repeat(auto-fill, 100%);
    width: 100%;
    height: 100vh;
    box-sizing: border-box; /* Inclui a espessura da borda na largura total */
  }
  .popup-box .popup{
    max-width: calc(100% - 15px);
  }
  .bottom-content .settings i{
    font-size: 17px;
  }
}
  </style>
  
  
 
  <script>
   
    /*function autoResize(element) {
        element.style.height = "auto";
        element.style.height = (element.scrollHeight) + "px";
    }


    function mostrarAdicionarCapa() {
        document.getElementById('fileLabel').style.display = 'inline-block';
    }

    document.getElementById('fileLabel').addEventListener('click', function() {
        document.getElementById('fileInput').click();
    });
    function toggleSettingsMenu() {
    var settingsMenu = document.getElementById('settings-menu');
    settingsMenu.classList.toggle('hidden');
  }
  function changeFont() {
    var fontSelect = document.getElementById('fontSelect');
    var selectedFont = fontSelect.value;
    document.getElementById('tituloPagina').style.fontFamily = selectedFont;
    atualizarTitulo(); // Adicionei isso para atualizar o título quando a fonte for alterada
  }

    function changeParagraph() {
      var selectedParagraph = $('#paragraphSelect').val();
      $('#app').css('text-align', selectedParagraph);
    }

    function changeFontSize() {
      var selectedFontSize = $('#fontSizeSelect').val();
      $('#app').css('font-size', selectedFontSize);
    }

    function toggleHighlight() {
      $('#app').toggleClass('highlighted-text');
    }
    var isSettingsMenuVisible = false; // Adicionado para rastrear o estado do menu

function toggleSettingsMenu() {
  var settingsMenu = document.getElementById('settings-menu');
  isSettingsMenuVisible = !isSettingsMenuVisible; // Inverte o estado ao clicar

  if (isSettingsMenuVisible) {
    // Se o menu estiver visível, mostre-o
    settingsMenu.classList.remove('hidden');
  } else {
    // Se o menu estiver oculto, oculte-o
    settingsMenu.classList.add('hidden');
  }
}
 // Adiciona um ouvinte de evento para detectar quando o usuário está digitando
 document.addEventListener('keydown', function() {
      // Mostra o menu de formatação quando o usuário começa a digitar
      document.getElementById('formatting-menu').style.display = 'flex';
    });

   // Função para atualizar o título
   function atualizarTitulo() {
            const tituloPagina = document.getElementById('tituloPagina');
            const novoTitulo = tituloPagina.innerText;
            document.title = novoTitulo;
        }

        // Função para atualizar o texto
        function atualizarTexto() {
            const textarea = document.getElementById('textarea');
            const novoTexto = textarea.value;
            // Faça o que você quiser com o novoTexto, como salvá-lo em algum lugar.
        }

        // Função para adicionar capa (coloque a lógica aqui)

        // Funções para formatação (por exemplo, negrito, itálico, sublinhado)

        // Função para alternar cores (se você quiser adicionar isso)
        let isPageBlack = false;
        function togglePageColor() {
            const body = document.body;
            isPageBlack = !isPageBlack;
            if (isPageBlack) {
                body.style.backgroundColor = 'black';
                body.style.color = 'white';
            } else {
                body.style.backgroundColor = 'white';
                body.style.color = 'black';
            }
        }*/


        const addBox = document.querySelector(".add-box"),
        popupBox = document.querySelector(".popup-box"),
        popupTitle = popupBox.querySelector("header p"),
        closeIcon = popupBox.querySelector("header i"),
        titleTag = popupBox.querySelector("input"),
        descTag = popupBox.querySelector("textarea"),
        addBtn = popupBox.querySelector("button");

const months = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho",
              "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
const notes = JSON.parse(localStorage.getItem("notes") || "[]");
let isUpdate = false, updateId;

addBox.addEventListener("click", () => {
    popupTitle.innerText = "Adicionar uma nova nota";
    addBtn.innerText = "Pronto!";
    popupBox.classList.add("show");
    document.querySelector("body").style.overflow = "hidden";
    if(window.innerWidth > 660) titleTag.focus();
});


closeIcon.addEventListener("click", () => {
    isUpdate = false;
    titleTag.value = descTag.value = "";
    popupBox.classList.remove("show");
    document.querySelector("body").style.overflow = "auto";
});

function showNotes() {
    if(!notes) return;
    document.querySelectorAll(".note").forEach(li => li.remove());
    notes.forEach((note, id) => {
        let filterDesc = note.description.replaceAll("\n", '<br/>');
        let liTag = `<li class="note">
                        <div class="details">
                            <p>${note.title}</p>
                            <span>${filterDesc}</span>
                        </div>
                        <div class="bottom-content">
                            <span>${note.date}x</span>
                            <div class="settings">
                                <i onclick="showMenu(this)" class="uil uil-ellipsis-h"></i>
                                <ul class="menu">
                                    <li onclick="updateNote(${id}, '${note.title}', '${filterDesc}')"><i class="uil uil-pen"></i>Edit</li>
                                    <li onclick="deleteNote(${id})"><i class="uil uil-trash"></i>Delete</li>
                                </ul>
                            </div>
                        </div>
                    </li>`;
        addBox.insertAdjacentHTML("afterend", liTag);
    });
}
showNotes();

function showMenu(elem) {
    elem.parentElement.classList.add("show");
    document.addEventListener("click", e => {
        if(e.target.tagName != "I" || e.target != elem) {
            elem.parentElement.classList.remove("show");
        }
    });
}

function deleteNote(noteId) {
    let confirmDel = confirm("Tem certeza que deseja excluir essa nota?");
    if(!confirmDel) return;
    notes.splice(noteId, 1);
    localStorage.setItem("notes", JSON.stringify(notes));
    showNotes();
}

function updateNote(noteId, title, filterDesc) {
    let description = filterDesc.replaceAll('<br/>', '\r\n');
    updateId = noteId;
    isUpdate = true;
    addBox.click();
    titleTag.value = title;
    descTag.value = description;
    popupTitle.innerText = "Alterando nota";
    addBtn.innerText = "Pronto!";
}

addBtn.addEventListener("click", e => {
    e.preventDefault();
    let title = titleTag.value.trim(),
    description = descTag.value.trim();

    if(title || description) {
        let currentDate = new Date(),
        month = months[currentDate.getMonth()],
        day = currentDate.getDate(),
        year = currentDate.getFullYear();

        let noteInfo = {title, description, date: `${month} ${day}, ${year}`}
        if(!isUpdate) {
            notes.push(noteInfo);
        } else {
            isUpdate = false;
            notes[updateId] = noteInfo;
        }
        localStorage.setItem("notes", JSON.stringify(notes));
        showNotes();
        closeIcon.click();
    }
});

document.addEventListener("DOMContentLoaded", function() {
    const fileInput = document.getElementById("fileInput");
    const addPhoto = document.getElementById("addPhoto");
    const pronto = document.getElementById("pronto");
    const descriptionTextarea = document.getElementById("descriptionTextarea");
    const selectedImage = document.getElementById("selectedImage");

    addPhoto.addEventListener("click", function() {
        fileInput.click();
    });

    fileInput.addEventListener("change", function() {
        const selectedFile = fileInput.files[0];

        if (selectedFile) {
            const reader = new FileReader();

            reader.onload = function(event) {
                const imageUrl = event.target.result;
                selectedImage.src = imageUrl;
                selectedImage.style.display = "block";
            };

            reader.readAsDataURL(selectedFile);
        }
    });

    pronto.addEventListener("click", function() {
        const description = descriptionTextarea.value;
        const imageSrc = selectedImage.src;

        // Salvar o texto e a imagem (imageSrc) como desejado, por exemplo, enviando para o servidor ou armazenando localmente.
        // Você também pode combinar o texto e a imagem como preferir.

        console.log("Texto:", description);
        console.log("URL da imagem:", imageSrc);

        // Limpar a imagem exibida
        selectedImage.style.display = "none";
    });
});

  function enviar(){
	  document.getElementById("anotacoes").submit();
  }


  </script>
  <script src="https://kit.fontawesome.com/7b7cd02c9e.js" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</body>
</html>



























