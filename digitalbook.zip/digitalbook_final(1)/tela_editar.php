<?php
require 'autoload.php';
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseACL;
use Parse\ParsePush;
use Parse\ParseUser;
use Parse\ParseInstallation;
use Parse\ParseException;
use Parse\ParseAnalytics;
use Parse\ParseFile;
use Parse\ParseCloud;
use Parse\ParseClient;
$app_id='KxaEmPPcjtpdi2dpvY6FZ41PPZbvmucoNgcwUQNw';
$rest_key='swcBixrt6EvNMu2H2ElfcaXF6avPsmheO0VV6pNQ';
$master_key='ZDtk0mNobUSSEFytF5lCo10HCRuqRzvx2O86okZ6';
ParseClient::initialize( $app_id, $rest_key, $master_key );
ParseClient::setServerURL('https://parseapi.back4app.com','/');
ParseClient::setCAFile(__DIR__ . '/certs/cacert.pem');


if (isset($_REQUEST['id'])){
	$id = $_REQUEST['id'];
	
    //Pego a tabela
    $tabela = new ParseQuery("Nota");
  
    //Busca o registro específico
    $obj = $tabela->get($id);
  
    //Recupera os valores
    $titulo = $obj->titulo;  
    $texto = $obj->texto;
    
	
}



//Se clicou em cadastrar
if (isset($_REQUEST['act'])){
	if ($_REQUEST['act'] == "cadastrar"){
		//Pego os dados do formulário
		$titulo = $_REQUEST['titulo'];
		$texto = $_REQUEST['texto'];
		
		$obj->set("titulo", $titulo);
		$obj->set("texto", $texto);
		
		$obj->save();
		
		header('Location: tela_anotacoes.php');
	}
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE-edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
  <link rel="stylesheet" href="css/nota.css">
  <link rel="icon" href="imagens/logo_original(8).png"style="width:1000px" type="image/x-icon">
  <title id="tituloPagina"> Digital Book </title>
  
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
<body  style="background-color:  #282828;">
  
  <div class="notes" id="app">
    <div class="popup-box">
      <div class="popup">
        <div class="content">
          <header>
            <p></p>
            <i class="uil uil-times"></i>
          </header>
	
        </div>
      </div>
    </div>
    
      
     
			<form method="post" style="background-color:#efedec;" action="tela_editar.php?act=cadastrar&id=<?php echo $id; ?>" id="anotacoes" enctype="multipart/form-data">  
            <div class="row title">
              <label>Título</label>
              <input type="text" name="titulo" style="background-color:#efedec;" spellcheck="false" value="<?php echo $titulo; ?>">
            </div>
            <div class="row description" style="margin-top: 30px;">
              <label >Descrição</label>
              <input type="file" name="file" id="fileInput" accept="image/*" >
              <center><img src="<?php echo $obj->foto->getURL(); ?>" width="100dp" height="100dp" /></center>
              <br>
              <textarea spellcheck="false" id="descriptionTextarea" name="texto" style="background-color:#efedec;"><?php echo $texto; ?></textarea>
            </div>
            <button name="cadastrar" onclick="enviar()"; style="margin-top: 450 px;">Pronto!</button>
            <p></p>            
            <a href="tela_anotacoes.php" class="beautiful-button" style="margin-top: 450 px; background-color:#414141; width: 857px; border-radius: 5px;">Voltar </a>
          </form>
			
      
    


  <!--<script src="js/anotaçao.js"></script>-->
  <style>
	form{
		margin: 30%;
		width: 90%;
	}
  
  
  
  
    body {
      font-family: 'Arial', sans-serif;
      margin: 0;
      padding: 0;
    }
  
    .notes__sidebar {
      background-color: #88ABFF;
      color: #ecf0f1;
      padding: 20px;
      width: 23%;
    }
  
    .logo {
      display: block;
      margin: 0 auto;
    }
  
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }

  form {
    width: 900px;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin: auto; /* Modificado para centralizar horizontalmente */
    text-align: center;
  }

  .row {
    margin-bottom: 15px;
    text-align: left;
  }

  label {
    display: block;
    margin-bottom: 5px;
  }

  input,
  textarea,
  button {
    width: 100%;
    padding: 8px;
    box-sizing: border-box;
    margin-top: 5px;
  }

  button {
   
    color: white;
    cursor: pointer;
  }

  
  #selectedImage {
    display: block;
    margin-top: 10px;
    max-width: 100px;
    max-height: 100px;
  }
  .beautiful-button {
    display: inline-block;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: bold;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    border: 2px solid #3498db;
    color: #ffffff;
    background-color: #3498db;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s, border-color 0.3s;
  }

  .beautiful-button:hover {
    background-color: #2980b9;
    border-color: #2980b9;
  }

  
    /* Estilos para a barra de pesquisa */
.pesquisa {
  display: flex;
  align-items: center;
  padding: 4px;
  margin: 0 4px;
  border-radius: 3px;
  background-color: #4c80fc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}



.pesquisa:hover {
  background-color: #0f4ad9;
}

.configuracao{
  display: flex;
  align-items: center;
  padding: 4px;
  margin: 0 4px;
  border-radius: 3px;
  background-color: #4c80fc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-top: 10px;
}

.configuracao:hover {
  background-color: #0f4ad9;
}

.caderno{
  display: flex;
  align-items: center;
  padding: 4px;
  margin: 0 4px;
  border-radius: 3px;
  background-color: #4c80fc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-top: 10px;
}

.caderno:hover{
  background-color: #0f4ad9;
}
.lixeira{
  display: flex;
  align-items: center;
  padding: 4px;
  margin: 0 4px;
  border-radius: 3px;
  background-color: #4c80fc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-top: 10px;
}

.lixeira:hover{
  background-color: #0f4ad9;

}





    /* Import Google Font - Poppins */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
body{
  background: #282828;
}
::selection{
  color: #fff;
  background: #618cf8;
}
.wrapper {
  margin: 50px;

}


.wrapper li{
  height: 250px;
  list-style: none;
  border-radius: 5px;
  padding: 15px 20px 20px;
  background: #fff;
  box-shadow: 0 4px 8px rgba(0,0,0,0.05);
}

.add-box, .icon, .bottom-content, 
.popup, header, .settings .menu li{
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.add-box{
  cursor: pointer;
  flex-direction: column;
  justify-content: center;
}
.add-box .icon{
  height: 78px;
  width: 78px;
  color: #88ABFF;
  font-size: 40px;
  border-radius: 50%;
  justify-content: center;
  border: 2px dashed #88ABFF;
}
.add-box p{
  color: #88ABFF;
  font-weight: 500;
  margin-top: 20px;
}
.note{
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.note .details{
  max-height: 165px;
  overflow-y: auto;
}
.note .details::-webkit-scrollbar,
.popup textarea::-webkit-scrollbar{
  width: 0;
}
.note .details:hover::-webkit-scrollbar,
.popup textarea:hover::-webkit-scrollbar{
  width: 5px;
}
.note .details:hover::-webkit-scrollbar-track,
.popup textarea:hover::-webkit-scrollbar-track{
  background: #f1f1f1;
  border-radius: 25px;
}
.note .details:hover::-webkit-scrollbar-thumb,
.popup textarea:hover::-webkit-scrollbar-thumb{
  background: #e6e6e6;
  border-radius: 25px;
}
.note p{
  font-size: 22px;
  font-weight: 500;
}
.note span{
  display: block;
  color: #575757;
  font-size: 16px;
  margin-top: 5px;
}
.note .bottom-content{
  padding-top: 10px;
  border-top: 1px solid #ccc;
}
.bottom-content span{
  color: #6D6D6D;
  font-size: 14px;
}
.bottom-content .settings{
  position: relative;
}
.bottom-content .settings i{
  color: #6D6D6D;
  cursor: pointer;
  font-size: 15px;
}
.settings .menu{
  z-index: 1;
  bottom: 0;
  right: -5px;
  padding: 5px 0;
  background: #fff;
  position: absolute;
  border-radius: 4px;
  transform: scale(0);
  transform-origin: bottom right;
  box-shadow: 0 0 6px rgba(0,0,0,0.15);
  transition: transform 0.2s ease;
}
.settings.show .menu{
  transform: scale(1);
}
.settings .menu li{
  height: 25px;
  font-size: 16px;
  margin-bottom: 2px;
  padding: 17px 15px;
  cursor: pointer;
  box-shadow: none;
  border-radius: 0;
  justify-content: flex-start;
}
.menu li:last-child{
  margin-bottom: 0;
}
.menu li:hover{
  background: #f5f5f5;
}
.menu li i{
  padding-right: 8px;
}

.popup-box{
  position: fixed;
  top: 0;
  left: 0;
  z-index: 2;
  height: 100%;
  width: 100%;
  background: rgba(0,0,0,0.4);
}
.popup-box .popup{
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 3;
  width: 100%;
  max-width: 400px;
  justify-content: center;
  transform: translate(-50%, -50%) scale(0.95);
}
.popup-box, .popup{
  opacity: 0;
  pointer-events: none;
  transition: all 0.25s ease;
}
.popup-box.show, .popup-box.show .popup{
  opacity: 1;
  pointer-events: auto;
}
.popup-box.show .popup{
  transform: translate(-50%, -50%) scale(1);
}
.popup .content{
  border-radius: 5px;
  background: #fff;
  width: calc(100% - 15px);
  box-shadow: 0 0 15px rgba(0,0,0,0.1);
}
.content header{
  padding: 15px 25px;
  border-bottom: 1px solid #ccc;
}
.content header p{
  font-size: 20px;
  font-weight: 500;
}
.content header i{
  color: #8b8989;
  cursor: pointer;
  font-size: 23px;
}
.content form{
  margin: 15px 25px 35px;
}
.content form .row{
  margin-bottom: 20px;
}
form .row label{
  font-size: 18px;
  display: block;
  margin-bottom: 6px;
}
form :where(input, textarea){
  height: 50px;
  width: 100%;
  outline: none;
  font-size: 17px;
  padding: 0 15px;
  border-radius: 4px;
  border: 1px solid #999;
  overflow: hidden;
}
form :where(input, textarea):focus{
  box-shadow: 0 2px 4px rgba(0,0,0,0.11);
}
form .row textarea{
  height: 150px;
  resize: none;
  padding: 8px 15px;
}
form button{
  width: 100%;
  height: 50px;
  color: #fff;
  outline: none;
  border: none;
  cursor: pointer;
  font-size: 17px;
  border-radius: 4px;
  background: #414141;
}

@media (max-width: 660px){
  .wrapper{
    margin: 15px;
    gap: 15px;
    grid-template-columns: repeat(auto-fill, 100%);
    width: 100%;
    height: 100vh;
    box-sizing: border-box; /* Inclui a espessura da borda na largura total */
  }
  .popup-box .popup{
    max-width: calc(100% - 15px);
  }
  .bottom-content .settings i{
    font-size: 17px;
  }
}
  </style>
  
  
 
  <script>
   
    


        const addBox = document.querySelector(".add-box"),
        popupBox = document.querySelector(".popup-box"),
        popupTitle = popupBox.querySelector("header p"),
        closeIcon = popupBox.querySelector("header i"),
        titleTag = popupBox.querySelector("input"),
        descTag = popupBox.querySelector("textarea"),
        addBtn = popupBox.querySelector("button");

const months = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho",
              "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
const notes = JSON.parse(localStorage.getItem("notes") || "[]");
let isUpdate = false, updateId;

addBox.addEventListener("click", () => {
    popupTitle.innerText = "Adicionar uma nova nota";
    addBtn.innerText = "Pronto!";
    popupBox.classList.add("show");
    document.querySelector("body").style.overflow = "hidden";
    if(window.innerWidth > 660) titleTag.focus();
});


closeIcon.addEventListener("click", () => {
    isUpdate = false;
    titleTag.value = descTag.value = "";
    popupBox.classList.remove("show");
    document.querySelector("body").style.overflow = "auto";
});

function showNotes() {
    if(!notes) return;
    document.querySelectorAll(".note").forEach(li => li.remove());
    notes.forEach((note, id) => {
        let filterDesc = note.description.replaceAll("\n", '<br/>');
        let liTag = `<li class="note">
                        <div class="details">
                            <p>${note.title}</p>
                            <span>${filterDesc}</span>
                        </div>
                        <div class="bottom-content">
                            <span>${note.date}x</span>
                            <div class="settings">
                                <i onclick="showMenu(this)" class="uil uil-ellipsis-h"></i>
                                <ul class="menu">
                                    <li onclick="updateNote(${id}, '${note.title}', '${filterDesc}')"><i class="uil uil-pen"></i>Edit</li>
                                    <li onclick="deleteNote(${id})"><i class="uil uil-trash"></i>Delete</li>
                                </ul>
                            </div>
                        </div>
                    </li>`;
        addBox.insertAdjacentHTML("afterend", liTag);
    });
}
showNotes();

function showMenu(elem) {
    elem.parentElement.classList.add("show");
    document.addEventListener("click", e => {
        if(e.target.tagName != "I" || e.target != elem) {
            elem.parentElement.classList.remove("show");
        }
    });
}

function deleteNote(noteId) {
    let confirmDel = confirm("Tem certeza que deseja excluir essa nota?");
    if(!confirmDel) return;
    notes.splice(noteId, 1);
    localStorage.setItem("notes", JSON.stringify(notes));
    showNotes();
}

function updateNote(noteId, title, filterDesc) {
    let description = filterDesc.replaceAll('<br/>', '\r\n');
    updateId = noteId;
    isUpdate = true;
    addBox.click();
    titleTag.value = title;
    descTag.value = description;
    popupTitle.innerText = "Alterando nota";
    addBtn.innerText = "Pronto!";
}

addBtn.addEventListener("click", e => {
    e.preventDefault();
    let title = titleTag.value.trim(),
    description = descTag.value.trim();

    if(title || description) {
        let currentDate = new Date(),
        month = months[currentDate.getMonth()],
        day = currentDate.getDate(),
        year = currentDate.getFullYear();

        let noteInfo = {title, description, date: `${month} ${day}, ${year}`}
        if(!isUpdate) {
            notes.push(noteInfo);
        } else {
            isUpdate = false;
            notes[updateId] = noteInfo;
        }
        localStorage.setItem("notes", JSON.stringify(notes));
        showNotes();
        closeIcon.click();
    }
});

document.addEventListener("DOMContentLoaded", function() {
    const fileInput = document.getElementById("fileInput");
    const addPhoto = document.getElementById("addPhoto");
    const pronto = document.getElementById("pronto");
    const descriptionTextarea = document.getElementById("descriptionTextarea");
    const selectedImage = document.getElementById("selectedImage");

    addPhoto.addEventListener("click", function() {
        fileInput.click();
    });

    fileInput.addEventListener("change", function() {
        const selectedFile = fileInput.files[0];

        if (selectedFile) {
            const reader = new FileReader();

            reader.onload = function(event) {
                const imageUrl = event.target.result;
                selectedImage.src = imageUrl;
                selectedImage.style.display = "block";
            };

            reader.readAsDataURL(selectedFile);
        }
    });

    pronto.addEventListener("click", function() {
        const description = descriptionTextarea.value;
        const imageSrc = selectedImage.src;

        // Salvar o texto e a imagem (imageSrc) como desejado, por exemplo, enviando para o servidor ou armazenando localmente.
        // Você também pode combinar o texto e a imagem como preferir.

        console.log("Texto:", description);
        console.log("URL da imagem:", imageSrc);

        // Limpar a imagem exibida
        selectedImage.style.display = "none";
    });
});

  function enviar(){
	  document.getElementById("anotacoes").submit();
  }

  


  </script>
  <script src="https://kit.fontawesome.com/7b7cd02c9e.js" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

  <!-- Botão de volta -->
  
</body>
</html>



























