<?php
require 'autoload.php';
use Parse\ParseObject;
use Parse\ParseQuery;
use Parse\ParseACL;
use Parse\ParsePush;
use Parse\ParseUser;
use Parse\ParseInstallation;
use Parse\ParseException;
use Parse\ParseAnalytics;
use Parse\ParseFile;
use Parse\ParseCloud;
use Parse\ParseClient;
$app_id='KxaEmPPcjtpdi2dpvY6FZ41PPZbvmucoNgcwUQNw';
$rest_key='swcBixrt6EvNMu2H2ElfcaXF6avPsmheO0VV6pNQ';
$master_key='ZDtk0mNobUSSEFytF5lCo10HCRuqRzvx2O86okZ6';
ParseClient::initialize( $app_id, $rest_key, $master_key );
// Users of Parse Server will need to point ParseClient at their remote URL and Mount Point:
ParseClient::setServerURL('https://parseapi.back4app.com','/');
ParseClient::setCAFile(__DIR__ . '/certs/cacert.pem');

// Inicia sessão
session_start();

if (isset($_GET['excluir'])) {
    // Pego os dados do formulário da URL
    $email = urldecode($_GET['email']);
    $senha = urldecode($_GET['senha']);

    // Configura a consulta para encontrar o usuário a ser excluído
    $query = new ParseQuery("Usuario");
    $query->equalTo("email", $email);
    $query->equalTo("senha", $senha); // Certifique-se de usar o nome do campo correto para a senha

    try {
        // Executa a consulta
        $usuario = $query->first();

        // Se encontrou o usuário, exclui
        if ($usuario) {
            $usuario->destroy();
            echo "Usuário excluído com sucesso.";
        } else {
            echo "Usuário não encontrado.";
        }
    } catch (ParseException $e) {
        echo "Erro ao excluir usuário: " . $e->getMessage();
    }
}


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuração da conta</title>

    <style>
        #profile-container {
            width: 150px;
            height: 150px;
            border: 2px solid #333;
            border-radius: 50%;
            overflow: hidden;
            margin: 0 auto;
        }
        #profile-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            
        }
        input[type="file"] {
            display: none;
        }
        label {
            display: inline-block;
            padding: 10px 15px;
          
            background-color: #007bff;
            color: rgb(0, 0, 0);
            cursor: pointer;
        }
        
        
    </style>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="css/signin.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css" rel="stylesheet">
</head>
<body style="background-color: #efedec; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh;">

    <form class="form-signin"  method="get" id="excluir" action="tela_config_conta.php?act=excluir" name="excluir" style="text-align: center;">
        <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email" autofocus style="background: #8a8a8a; border-radius: 86px">
        <p></p>
        <input type="password" id="inputSenha" name="senha" class="form-control" placeholder="Senha" style="background: #8a8a8a; border-radius: 86px">
        <p></p>
        <button type="submit"  name="excluir" id="excluir" style="background: #282828; border-radius: 86px; color: #fff; width: 154px; display: inline-block; text-align: center; text-decoration: none; padding: 6px;" >Excluir conta </button>
         <br><br>
        <a href="tela_anotacoes.php" class="beautiful-button" style="background:#282828; border-radius: 86px; color:#fff; width: 154px; display: inline-block; text-align: center; text-decoration: none; padding: 6px;">Voltar</a>

    </form>

    <script>
            

            function deletar(usuario){

//alert(nota);
window.location.href = "tela_config_conta.php?act=excluir";
}

        </script>
        

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>
